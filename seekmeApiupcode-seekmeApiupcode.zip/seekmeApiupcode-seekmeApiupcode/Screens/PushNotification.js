import { Text, View } from 'react-native'
import React, { Component } from 'react'

export class PushNotification extends Component {
    let= "abcs"
  render() {
    return (
      <View>
        <Text>PushNotification</Text>
      </View>
    )
  }
}

export default PushNotification