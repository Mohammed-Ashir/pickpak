// export const baseUrl = 'https://pickpic4u.com/app.pickpic4u.com/index.php/api/';
export const baseUrl = 'https://pickpic4u.com/api/';

// export const baseUrl = 'https://priceapp.co.za/_NEWPROJECT/api/';
// export const baseUrl = 'https://app.pickpic4u.com/api/';

export const ImagebaseUrl = 'https://www.dayscab.com/tequ/uploads/users/';
export const mapsApiKey = '&key=AIzaSyAOfvwprFhTik0bSONiOm7t3UB8ePwVRIY';
export const LocationLink =
  'https://maps.googleapis.com/maps/api/geocode/json?latlng=';
