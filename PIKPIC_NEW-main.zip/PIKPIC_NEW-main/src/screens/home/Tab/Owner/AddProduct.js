import {useRoute} from "@react-navigation/native";
import React, {useState} from "react";
import {
  ActivityIndicator,
  Dimensions,
  FlatList,
  Image,
  ImageBackground,
  Modal,
  ScrollView,
  TouchableOpacity,
  useWindowDimensions,
  View,
} from "react-native";
import ImagePicker from "react-native-image-crop-picker";
import {launchCamera, launchImageLibrary} from "react-native-image-picker";
import {useSelector} from "react-redux";
import Button from "../../../../components/Button";
import Header from "../../../../components/Header";
import Statusbar from "../../../../components/Statusbar";
import TextFormated from "../../../../components/TextFormated";
import TextInput from "../../../../components/TextInput";
import {baseUrl} from "../../../../utils/constance";
import {theme} from "../../../../utils/theme";
import {ShowToast} from "../../../../utils/ToastFunction";
import PickerInput from "../../../../components/PickerInput";
import {
  GestureEvent,
  PanGestureHandler,
  PanGestureHandlerEventPayload,
} from "react-native-gesture-handler";
import ImageEditor from "@react-native-community/image-editor";

const Availablity = [
  {
    id: "1",
    DisplayName: "HAND TO HAND",
    title: "AT STORE",
    time: "Minutes",
  },
  // {
  //   id: '2',
  //   title: 'TAKE OUT',
  //   time: 'Houre',
  // },
  // {
  //   id: '3',
  //   title: 'DELIVERY',
  //   time: 'Day',
  // },
];
const data = [
  {
    id: "1",
    title: "AT STORE",
    time: "Minutes",
  },
  {
    id: "2",
    title: "TAKE OUT",
    time: "Houre",
  },
  {
    id: "3",
    title: "DELIVERY",
    time: "Day",
  },
  {
    id: "5",
    title: "DELIVERY",
    time: "Week",
  },
  {
    id: "6",
    title: "DELIVERY",
    time: "Month",
  },
  {
    id: "7",
    title: "DELIVERY",
    time: "Year",
  },
];
const Minute = [
  {
    id: "10",
    title: "AT STORE",
    time: "10 minutes",
  },
  {
    id: "30",
    title: "TAKE OUT",
    time: "30 minutes",
  },
  {
    id: "59",
    title: "DELIVERY",
    time: "59 minutes",
  },
];
const hour = [
  {
    id: "1",
    title: "AT STORE",
    time: "1 houre",
  },
  {
    id: "2",
    title: "TAKE OUT",
    time: "2 houre",
  },
  {
    id: "3",
    title: "DELIVERY",
    time: "3 houre",
  },
  {
    id: "4",
    title: "DELIVERY",
    time: "4 houre",
  },
  {
    id: "5",
    title: "DELIVERY",
    time: "5 houre",
  },
  {
    id: "6",
    title: "DELIVERY",
    time: "6 houre",
  },
  {
    id: "7",
    title: "DELIVERY",
    time: "7 houre",
  },
  {
    id: "8",
    title: "DELIVERY",
    time: "8 houre",
  },
  {
    id: "9",
    title: "DELIVERY",
    time: "9 houre",
  },
  {
    id: "10",
    title: "DELIVERY",
    time: "10 houre",
  },
  {
    id: "11",
    title: "AT STORE",
    time: "11 houre",
  },
  {
    id: "12",
    title: "TAKE OUT",
    time: "12 houre",
  },
  {
    id: "13",
    title: "DELIVERY",
    time: "13 houre",
  },
  {
    id: "14",
    title: "DELIVERY",
    time: "14 houre",
  },
  {
    id: "15",
    title: "DELIVERY",
    time: "15 houre",
  },
  {
    id: "16",
    title: "DELIVERY",
    time: "16 houre",
  },
  {
    id: "17",
    title: "DELIVERY",
    time: "17 houre",
  },
  {
    id: "18",
    title: "DELIVERY",
    time: "18 houre",
  },
  {
    id: "19",
    title: "DELIVERY",
    time: "19 houre",
  },
  {
    id: "20",
    title: "DELIVERY",
    time: "20 houre",
  },
  {
    id: "21",
    title: "DELIVERY",
    time: "21 houre",
  },
  {
    id: "22",
    title: "DELIVERY",
    time: "22 houre",
  },
  {
    id: "23",
    title: "DELIVERY",
    time: "23 houre",
  },
];
const Day = [
  {
    id: "1",
    title: "AT STORE",
    time: "1 day",
  },
  {
    id: "2",
    title: "TAKE OUT",
    time: "2 day",
  },
  {
    id: "3",
    title: "DELIVERY",
    time: "3 day",
  },
  {
    id: "4",
    title: "DELIVERY",
    time: "4 day",
  },
  {
    id: "5",
    title: "DELIVERY",
    time: "5 day",
  },
  {
    id: "6",
    title: "DELIVERY",
    time: "6 day",
  },
];
const Week = [
  {
    id: "1",
    title: "AT STORE",
    time: "1 week",
  },
  {
    id: "2",
    title: "TAKE OUT",
    time: "2 week",
  },
  {
    id: "3",
    title: "DELIVERY",
    time: "3 week",
  },
  {
    id: "4",
    title: "DELIVERY",
    time: "4 week",
  },
];
const month = [
  {
    id: "1",
    title: "AT STORE",
    time: "1 month",
  },
  {
    id: "2",
    title: "TAKE OUT",
    time: "2 month",
  },
  {
    id: "3",
    title: "DELIVERY",
    time: "3 month",
  },
  {
    id: "4",
    title: "DELIVERY",
    time: "4 month",
  },
  {
    id: "5",
    title: "DELIVERY",
    time: "5 month",
  },
  {
    id: "6",
    title: "DELIVERY",
    time: "6 month",
  },
  {
    id: "7",
    title: "DELIVERY",
    time: "7 month",
  },
  {
    id: "8",
    title: "DELIVERY",
    time: "8 month",
  },
  {
    id: "9",
    title: "DELIVERY",
    time: "9 month",
  },
  {
    id: "10",
    title: "DELIVERY",
    time: "10 month",
  },
  {
    id: "11",
    title: "DELIVERY",
    time: "11 month",
  },
];
const year = [
  {
    id: "1",
    title: "AT STORE",
    time: "1 year",
  },
  {
    id: "2",
    title: "TAKE OUT",
    time: "2 year",
  },
  {
    id: "3",
    title: "DELIVERY",
    time: "3 year",
  },
  {
    id: "4",
    title: "DELIVERY",
    time: "4 year",
  },
  {
    id: "5",
    title: "DELIVERY",
    time: "5 year",
  },
  {
    id: "6",
    title: "DELIVERY",
    time: "6 year",
  },
  {
    id: "7",
    title: "DELIVERY",
    time: "7 year",
  },
];

export default function LogOut({navigation}) {
  const {params} = useRoute();
  const [image, setImage] = useState("");
  const [uri, setUri] = useState("");
  const [imageExtraData, setImageExtraData] = useState("");
  const [price, setPrice] = useState("");
  const [allPrices, setAllPrices] = useState([]);
  const [all_Rent_Prices, setAll_Rent_Prices] = useState([]);
  const [all_Rent_timing, setAll_Rent_timing] = useState([]);
  const [all_Rent_Period, setAll_Rent_Period] = useState([]);
  const [Rentprice, setRentPrice] = useState("");
  const [modal, setModal] = useState(false);
  const [modalTwo, setModalTwo] = useState(false);
  const [modalThree, setModalThree] = useState(false);
  const dimensionsss = useWindowDimensions();
  const [selected, setSelected] = useState([]);
  const [takeout, setTakeout] = useState("");
  const [delivery, setDelivery] = useState("");

  const auth = useSelector(state => state.auth);
  const [loading, setLoading] = useState(false);
  const [cropImg, setCropImg] = useState("");
  const [onpress_In, setOnpress_In] = useState([]);
  const [onpress_Out, setOnpress_Out] = useState([]);
  const [Product, setProduct] = useState([]);
  const [time, setTime] = useState("");
  const [timePeriod, setTimePeriod] = useState("");
  // alert(JSON.stringify(all_Rent_Prices));
  // alert(JSON.stringify(imageExtraData.type));
  console.log("Product", Product);
  const [cropped_Images, setCropped_Images] = useState([]);

  const [start, setStart] = useState();
  const [end, setEnd] = useState();
  const [dimensions, setDimensions] = useState();
  console.log("cropped_Images", cropped_Images);

  const Crop_img = () => {
    ImagePicker.openCropper({
      path: uri.uri,
      width: 450,
      height: 450,
      maxFiles: 1,
      cropperRotateButtonsHidden: false,
      showCropFrame: false,
    }).then(image => {
      console.log(image.path);
      setUri({uri: image.path});
      setProduct([]);
      setAllPrices([]);
      setAll_Rent_Prices([]);
      setAll_Rent_timing([]);
      setAll_Rent_Period([]);
    });
  };

  const pickImage = () => {
    launchImageLibrary(
      {quality: 1, mediaType: "photo", includeExtra: true},
      response => {
        if (!response.didCancel) {
          console.log("response?.assets[0]", response?.assets[0]);
          setImageExtraData(response?.assets[0]);
          setTimeout(() => {
            // setModalThree(false);
            ImagePicker.openCropper({
              path: response?.assets[0],
              width: 450,
              height: 450,
              maxFiles: 1,
              cropperRotateButtonsHidden: false,
              showCropFrame: false,
            }).then(image => {
              console.log(image.path);
              setUri({
                uri: image.path,
                height: image.height,
                width: image.width,
              });
              setProduct([]);
              setAllPrices([]);
              setAll_Rent_Prices([]);
              setAll_Rent_timing([]);
              setAll_Rent_Period([]);
              setModalThree(false);
            });
          }, 1000);
        }
      },
    );
  };
  const picCamera = () => {
    launchCamera({quality: 1, mediaType: "photo"}, response => {
      if (!response.didCancel) {
        console.log("response?.assets[0]", response?.assets[0]);
        setImageExtraData(response?.assets[0]);
        setTimeout(() => {
          // setModalThree(false);
          ImagePicker.openCropper({
            path: response?.assets[0],
            width: 450,
            height: 450,
            maxFiles: 1,
            cropperRotateButtonsHidden: false,
            showCropFrame: false,
          }).then(image => {
            console.log(image.path);
            setUri({
              uri: image.path,
              height: image.height,
              width: image.width,
            });
            setProduct([]);
            setAllPrices([]);
            setAll_Rent_Prices([]);
            setAll_Rent_timing([]);
            setAll_Rent_Period([]);
            setModalThree(false);
          });
        }, 1000);
      }
    });
  };

  // const picCamera = () => {
  //   launchCamera({quality: 1, mediaType: 'photo'}, response => {
  //     if (!response.didCancel) {
  //       setCropImg('');
  //       setUri(response?.assets[0]);
  //       setModalThree(false);
  //     }
  //   });
  // };

  async function AddProduct() {
    try {
      setLoading(true);
      const url = baseUrl + "post_product";

      const body = new FormData();

      body.append("user_id", auth.id);
      body.append("avaibility_atstor", selected[0]);
      body.append("tackout", "");
      body.append("avaibility_test", "");
      body.append("avaibility_delivery", "");
      body.append("price", allPrices.join(","));
      body.append("rent_price", all_Rent_Prices.join(","));
      body.append("rent_type", all_Rent_timing.join(","));
      body.append("rent_timing", all_Rent_Period.join(","));
      console.log(
        Product.map((v, i) =>
          v.map((v, i) =>
            i % 2 == 0
              ? v / (dimensionsss.width - 30)
              : v / (dimensionsss.height / 3),
          ),
        ).join(","),
      );
      body.append(
        "post_position",
        Product.map((v, i) =>
          v.map((v, i) =>
            i % 2 == 0
              ? v / (dimensionsss.width - 30)
              : v / (dimensionsss.height / 3),
          ),
        ).join(","),
      );

      body.append("image", {
        uri: uri.uri,
        type: imageExtraData.type,
        name: imageExtraData.fileName,
      });
      {
        cropped_Images.map(v =>
          body.append("cropped_images[]", {
            uri: v,
            type: imageExtraData.type,
            name: imageExtraData.fileName,
          }),
        );
      }
      console.log("post_product", body);
      // return;

      console.log("JSON.stringify(body)", JSON.stringify(body));
      // return;
      const res = await fetch(url, {
        method: "POST",
        body: body,
        headers: {
          "content-type": "multipart/form-data",
        },
      });
      console.log(res);
      const rslt = await res.json();
      console.log(rslt);

      if (rslt.success == "1") {
        // alert(JSON.stringify(!rslt.post_data.price));
        if (allPrices.length == 0) {
          AskUpdate(rslt?.post_data[0]?.id);
        }
        if (all_Rent_Prices.length != 0) {
          RentUpdate(rslt?.post_data[0]?.id);
        }
        // setLoading(false);
        // return;
        setModalTwo(false);
        navigation.goBack();
        ShowToast("Product added successfully");
      } else {
        // ShowToast(rslt.message || 'Unknown error', 'error');
      }
      setLoading(false);
    } catch (e) {
      setLoading(false);
      // alert('An error occured.');
      ShowToast("An error occured.", "error");

      console.log(e);
    }
  }

  async function RentUpdate(id) {
    try {
      const url =
        baseUrl +
        "update_status_rent_ask?id=" +
        id +
        "&rent_status=YES&avaibility_atstor=" +
        selected[0] +
        "&avaibility_tackout=" +
        selected[1];
      "&avaibility_delivery=" + selected[2];
      console.log("ask_status", url);
      // return;

      const res = await fetch(url, {
        method: "GET",
        headers: {"Cache-Control": "no-cache"},
      });
      console.log(res);
      const rslt = await res.json();
      console.log(rslt);

      if (rslt.success == "1") {
      } else {
        // ShowToast(rslt.message || 'Unknown error', 'error');
      }
    } catch (e) {
      // alert('An error occured.');
      ShowToast("An error occured.", "error");
      console.log(e);
    }
  }
  async function AskUpdate(id) {
    try {
      const url =
        baseUrl +
        "update_status_rent_ask?id=" +
        id +
        "&ask_status=YES&avaibility_atstor=" +
        selected[0] +
        "&avaibility_tackout=" +
        selected[1];
      "&avaibility_delivery=" + selected[2];
      console.log("ask_status", url);
      // return;

      const res = await fetch(url, {
        method: "GET",
        headers: {"Cache-Control": "no-cache"},
      });
      console.log(res);
      const rslt = await res.json();
      console.log(rslt);

      if (rslt.success == "1") {
      } else {
        // ShowToast(rslt.message || 'Unknown error', 'error');
      }
    } catch (e) {
      // alert('An error occured.');
      ShowToast("An error occured.", "error");
      console.log(e);
    }
  }
  console.log(onpress_In, onpress_Out);

  const onPress = (event: GestureEvent<PanGestureHandlerEventPayload>) => {
    if (!uri) return;
    const {x, y, translationX, translationY} = event.nativeEvent;
    if (!start) setStart({x: y, y: x});
    setDimensions({w: translationX, h: translationY});
  };

  const onEnd = () => {
    if (!start) return;

    setEnd(start);
    setStart(null);
  };
  // console.log('product', Product);
  // alert(JSON.stringify(start.length));
  // console.log(start);

  return (
    <View style={{flex: 1, backgroundColor: theme.colors.primary}}>
      <Statusbar backgroundColor="#fff" barStyle="dark-content" />
      <ScrollView
        // scrollEnabled={false}
        contentContainerStyle={{justifyContent: "space-between"}}>
        <View>
          <Header navigation={navigation} Headertext={"Shop"} />
          <View
            style={{
              height: dimensionsss.width - 30,
              width: dimensionsss.width - 30,
              alignSelf: "center",
              overflow: "hidden",
            }}>
            <TouchableOpacity
              activeOpacity={1}
              disabled={uri == "" ? true : false}
              style={{
                width: dimensionsss.width - 30,
                height: dimensionsss.width - 30,
                alignSelf: "center",
                backgroundColor: theme.colors.Tabbg,
              }}
              onPressIn={e => {
                const X = e.nativeEvent.locationX;
                const Y = e.nativeEvent.locationY;

                setOnpress_In([X, Y]);

                // setOnpress_Out([]);
              }}
              onPressOut={e => {
                const X = e.nativeEvent.locationX;
                const Y = e.nativeEvent.locationY;
                if (onpress_In[0] == X || onpress_In[1] == Y) {
                  ShowToast(
                    "What are you selecting so small? you 🤬 ?",
                    "error",
                  );
                  setOnpress_In([]);
                  setOnpress_Out([]);
                  return;
                }

                // setOnpress_Out([X, Y]);
                const item = [
                  Math.min(onpress_In[0], X),
                  Math.min(onpress_In[1], Y),
                  Math.max(onpress_In[0], X) + 15,
                  Math.max(onpress_In[1], Y) + 15,
                ];
                setProduct(v => [...v, item]);
                setOnpress_In([item[0], item[1]]);
                setOnpress_Out([item[3], item[4]]);
                const cropData = {
                  offset: {
                    x: (item[0] / dimensionsss.width) * uri.width,
                    y: (item[1] / dimensionsss.width) * uri.height,
                  },
                  size: {
                    width: Math.abs(
                      ((item[2] - item[0]) / dimensionsss.width) * uri.width,
                    ),
                    height: Math.abs(
                      ((item[3] - item[1]) / dimensionsss.width) * uri.height,
                    ),
                  },
                };
                console.log("helloooo", item, uri, dimensionsss, cropData);
                ImageEditor.cropImage(uri, cropData)
                  .then(url => {
                    console.log("Cropped image uri", url);
                    // setCropped_Images(url);
                    // setCropped_Images(url)
                    setCropped_Images(v => [...v, url]);
                  })
                  .catch(e => console.log("cibhuytvbuy: ", e));

                setModal(true);
              }}>
              <PanGestureHandler onGestureEvent={onPress} onEnded={onEnd}>
                <View
                  style={{
                    width: dimensionsss.width - 30,
                    height: dimensionsss.width - 30,
                    alignSelf: "center",
                  }}>
                  <ImageBackground
                    source={{uri: cropImg != "" ? cropImg : uri.uri}}
                    style={{
                      width: dimensionsss.width - 30,
                      height: dimensionsss.width - 30,
                      alignSelf: "center",
                      backgroundColor: theme.colors.Tabbg,
                    }}
                    imageStyle={{
                      resizeMode: "contain",
                      borderWidth: 1,
                      width: dimensionsss.width - 30,
                      height: dimensionsss.width - 30,
                      borderColor: theme.colors.yellow,
                    }}>
                    {start != undefined && (
                      <View
                        style={{
                          position: "absolute",
                          borderColor: "red",
                          top: (start?.x ?? end?.x) - 8,
                          left: (start?.y ?? end?.y) - 8,
                          width: dimensions?.w ?? 0,
                          height: dimensions?.h ?? 0,
                          borderWidth: 2,
                        }}
                      />
                    )}
                  </ImageBackground>
                </View>
              </PanGestureHandler>
            </TouchableOpacity>
            {Product.map(item => (
              <View
                style={{
                  position: "absolute",
                  borderWidth: 2,
                  borderColor: theme.colors.red,
                  left: item[0],
                  top: item[1],
                  width: item[2] - item[0] - 15,
                  height: item[3] - item[1] - 15,
                  backgroundColor: theme.colors.inputBG + "73",
                }}>
                {/* <TextFormated
                  style={{
                    fontSize: 12,
                    marginTop: 5,
                    fontWeight: '600',
                    color: 'black',
                  }}>
                  ¥{allPrices.reduce((a, b) => a + (parseInt(b) || 0), 0)}
                </TextFormated> */}
              </View>
            ))}
          </View>

          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              marginTop: dimensionsss.width / 4,
              marginHorizontal: 15,
            }}>
            <TouchableOpacity
              disabled={allPrices.length != 0 ? true : false}
              onPress={() => {
                if (uri == "") {
                  setModalThree(true);
                  // setCropped_Images('');
                } else {
                  Crop_img();
                  // setCropped_Images('');
                }
              }}
              style={{
                alignItems: "center",
                justifyContent: "center",
                paddingVertical: 15,
                flexDirection: "row",
                borderRadius: 50,
                backgroundColor: theme.colors.yellow,
                flex: 1,
                shadowColor: "#000",
                shadowOffset: {
                  width: 0,
                  height: 2,
                },
                shadowOpacity: 0.25,
                shadowRadius: 3.84,

                elevation: 5,
              }}>
              <TextFormated
                style={{
                  fontWeight: "700",
                  color: theme.colors.primary,
                  fontSize: 16,
                }}>
                {uri == "" ? " SELECT IMAGE" : "ADJUST PICTURE"}
              </TextFormated>
            </TouchableOpacity>
          </View>

          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              marginHorizontal: 15,
              marginVertical: 40,
              backgroundColor: theme.colors.primary,
              shadowColor: "#000",
              shadowOffset: {
                width: 0,
                height: 2,
              },
              shadowOpacity: 0.25,
              shadowRadius: 3.84,

              elevation: 5,
              paddingVertical: 12,
              borderRadius: 20,
            }}>
            <View style={{alignItems: "center"}}>
              <Image
                source={require("../../../../assets/shoppingcart.png")}
                style={{
                  width: 45,
                  height: 45,
                  resizeMode: "contain",
                  marginHorizontal: 15,
                }}
              />
              {allPrices.reduce((a, b) => a + (parseInt(b) || 0), 0) >= 1 && (
                <TextFormated
                  style={{
                    fontSize: 12,
                    marginTop: 5,
                    fontWeight: "600",
                    color: "black",
                  }}>
                  ¥{allPrices.reduce((a, b) => a + (parseInt(b) || 0), 0)}
                </TextFormated>
              )}
            </View>
            <FlatList
              data={cropped_Images}
              // data={Product.slice(0, cropImg.length != '' && 1)}
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={{marginVertical: 0}}
              // style={{flex: 1}}
              horizontal={true}
              renderItem={({item, index}) => (
                <View style={{alignItems: "center", marginHorizontal: 10}}>
                  <ImageBackground
                    // source={{uri: cropped_Images}}
                    source={{uri: item}}
                    style={{
                      minWidth: 100,
                      borderWidth: 1,
                      minHeight: 120,
                      borderRadius: 10,
                      overflow: "hidden",
                    }}
                    imageStyle={{
                      height: 120,
                      width: 100,
                      resizeMode: "contain",
                    }}
                    // imageStyle={{
                    //   borderRadius: 10,
                    //   resizeMode: 'stretch',
                    //   minWidth:
                    //     ((dimensionsss.width - 30) * 90) / (item[2] - item[0]),
                    //   minHeight:
                    //     ((dimensionsss.height / 3.5) * 150) /
                    //     (item[3] - item[1]),
                    //   borderWidth: 1,
                    //   top:
                    //     -(
                    //       (((dimensionsss.height / 3.5) * 60) /
                    //         (item[3] - item[1])) *
                    //       item[1]
                    //     ) /
                    //     (dimensionsss.height / 3.5),
                    //   left:
                    //     -(
                    //       (((dimensionsss.width - 30) * 80) /
                    //         (item[2] - item[0])) *
                    //       item[0]
                    //     ) /
                    //     (dimensionsss.width - 30),
                    //   // height: dimensionsss.height / 3.5,
                    // }}
                  >
                    <View style={{position: "absolute", right: 7, top: 5}}>
                      <TouchableOpacity
                        onPress={() => {
                          setAllPrices(v => [
                            ...v.slice(0, index),
                            ...v.slice(index + 1),
                          ]);
                          setAll_Rent_Prices(v => [
                            ...v.slice(0, index),
                            ...v.slice(index + 1),
                          ]);
                          setAll_Rent_timing(v => [
                            ...v.slice(0, index),
                            ...v.slice(index + 1),
                          ]);
                          setAll_Rent_Period(v => [
                            ...v.slice(0, index),
                            ...v.slice(index + 1),
                          ]);
                          setProduct(v => [
                            ...v.slice(0, index),
                            ...v.slice(index + 1),
                          ]);
                          setCropped_Images(v => [
                            ...v.slice(0, index),
                            ...v.slice(index + 1),
                          ]);
                        }}>
                        <Image
                          source={require("../../../../assets/Close.png")}
                          style={{
                            width: 14,
                            height: 14,
                            resizeMode: "contain",
                          }}
                        />
                      </TouchableOpacity>
                    </View>
                  </ImageBackground>

                  {!!allPrices[index] && (
                    <TextFormated
                      style={{
                        fontSize: 16,
                        marginTop: 5,
                        fontWeight: "600",
                        color: "black",
                      }}>
                      ¥{allPrices[index]}
                      {/* ¥{allPrices[index]} */}
                    </TextFormated>
                  )}
                </View>
              )}
            />
          </View>

          <View style={{marginVertical: 20, marginHorizontal: 15}}>
            <FlatList
              data={Availablity}
              numColumns={4}
              contentContainerStyle={{}}
              scrollEnabled={false}
              renderItem={({item, index}) => (
                <TouchableOpacity
                  onPress={() => {
                    // setSelected([]);
                    setSelected(prevState =>
                      prevState.find(v => item.title == v)
                        ? prevState.filter(v => item.title != v)
                        : [...prevState, item.title],
                    );
                  }}
                  style={{
                    backgroundColor: selected.find(v => v == item.title)
                      ? theme.colors.yellow
                      : theme.colors.SelectAvailablity,
                    shadowColor: "#000",
                    shadowOffset: {
                      width: 0,
                      height: 2,
                    },
                    shadowOpacity: 0.25,
                    shadowRadius: 3.84,

                    elevation: 5,
                    alignItems: "center",
                    justifyContent: "center",
                    paddingVertical: 18,
                    flexDirection: "row",
                    borderRadius: 5,
                    // width: Dimensions.get('window').width / 3.65,
                    flex: 1,
                  }}>
                  <TextFormated
                    style={{
                      fontWeight: "700",
                      color: theme.colors.primary,
                      fontSize: 10,
                    }}>
                    {/* ONLY FRONTEND ME AT STORE KO CHANGE KARKE HAND TO HAND KIYA HE BAAKI PURE APP ME AT STORE KE HI CHECKS LAGE HUE HE   */}
                    {item.DisplayName}
                  </TextFormated>
                </TouchableOpacity>
              )}
            />
          </View>

          <TouchableOpacity
            onPress={() => {
              if (uri == "") {
                ShowToast("Please select image", "error");
                return;
              }
              if (selected.length == 0) {
                ShowToast("Please select delivery style", "error");
                return;
              }
              AddProduct();
            }}
            style={{
              alignItems: "center",
              justifyContent: "center",
              paddingVertical: 15,
              flexDirection: "row",
              borderRadius: 6,
              backgroundColor: theme.colors.green,
              // flex: 1,
              shadowColor: "#000",
              shadowOffset: {
                width: 0,
                height: 2,
              },
              shadowOpacity: 0.25,
              shadowRadius: 3.84,

              elevation: 5,
              marginHorizontal: 15,
              marginVertical: 20,
            }}>
            {/* {loading ? (
              <ActivityIndicator
                size={'small'}
                style={{margin: 2}}
                color="#fff"
              />
            ) : ( */}

            {loading ? (
              <ActivityIndicator
                size={"small"}
                style={{margin: 2}}
                color="#fff"
              />
            ) : (
              <TextFormated
                style={{
                  fontWeight: "700",
                  color: theme.colors.primary,
                  fontSize: 16,
                }}>
                SUBMIT
              </TextFormated>
            )}
            {/* )} */}
          </TouchableOpacity>
        </View>
      </ScrollView>

      <Modal
        animationType="fade"
        visible={modal}
        onDismiss={() => {
          setModal(false);
        }}
        transparent
        style={{}}>
        <TouchableOpacity
          // onPress={() => {
          //   if (price == '') {
          //     ShowToast('Please enter selected product price', 'error');
          //     return;
          //   }
          //   if (price < 1) {
          //     ShowToast('Please enter selected product price', 'error');
          //     return;
          //   }
          //   if (Rentprice != '') {
          //     setAll_Rent_Prices(v => v.concat(Rentprice));
          //   }
          //   if (all_Rent_Prices == null) {
          //     setAll_Rent_Prices([]);
          //   }
          //   setModal(false);
          // }}
          activeOpacity={1}
          style={{
            justifyContent: "center",
            alignItems: "center",
            backgroundColor: "transparent",
            backgroundColor: theme.colors.Black + "33",
            width: Dimensions.get("window").width,
            height: Dimensions.get("window").height,
          }}>
          <TouchableOpacity
            activeOpacity={1}
            style={{
              backgroundColor: theme.colors.primary,
              width: Dimensions.get("window").width - 40,
              height: Dimensions.get("window").width - 200,
              // height: Dimensions.get('window').width - 100,
              alignItems: "center",
              borderRadius: 20,
              borderWidth: 0.4,
              borderColor: theme.colors.Light_Gray,
              marginBottom: 45,
            }}>
            <View
              style={{
                flex: 1,
                justifyContent: "center",
                borderRadius: 20,
                overflow: "hidden",
                alignItems: "flex-start",
              }}>
              <TextFormated
                style={{fontSize: 16, fontWeight: "600", alignSelf: "center"}}>
                Enter Price
              </TextFormated>
              <View
                style={{
                  marginVertical: 20,
                  flexDirection: "row",
                  alignItems: "center",
                }}>
                <TouchableOpacity
                  activeOpacity={1}
                  style={{
                    alignItems: "center",
                    justifyContent: "center",
                    borderRadius: 6,
                    backgroundColor: theme.colors.purple,
                    flex: 0.5,
                    paddingHorizontal: 5,
                    marginRight: 10,
                    paddingVertical: 10,
                    marginTop: 9,
                  }}>
                  <TextFormated
                    style={{
                      fontWeight: "700",
                      color: theme.colors.primary,
                      fontSize: 12,
                    }}>
                    Order
                  </TextFormated>
                </TouchableOpacity>
                <TextInput
                  View_marginTop={0}
                  paddingTop={8}
                  paddingBottom={8}
                  paddingHorizontal={0.1}
                  marginTop={0}
                  width={Dimensions.get("window").width / 3.4}
                  placeholder="Enter Price"
                  value={price}
                  onChangeText={setPrice}
                  autoFocus={true}
                  keyboardType="number-pad"
                />
                <View style={{width: 10}} />
                <TextInput
                  View_marginTop={0}
                  paddingHorizontal={0.1}
                  marginTop={0}
                  paddingTop={8}
                  paddingBottom={8}
                  width={Dimensions.get("window").width / 5.4}
                  placeholder="JPY"
                  editable={false}
                />
              </View>
              {/* <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  marginBottom: 20,
                }}>
                <TouchableOpacity
                  activeOpacity={1}
                  style={{
                    alignItems: 'center',
                    justifyContent: 'center',
                    borderRadius: 6,
                    backgroundColor: theme.colors.Chat_container,
                    flex: 0.5,
                    paddingHorizontal: 5,
                    marginRight: 10,
                    paddingVertical: 10,
                    marginTop: 9,
                  }}>
                  <TextFormated
                    style={{
                      fontWeight: '700',
                      color: theme.colors.primary,
                      fontSize: 12,
                    }}>
                    Rent
                  </TextFormated>
                </TouchableOpacity>
                <TextInput
                  paddingHorizontal={0.1}
                  View_marginTop={0}
                  paddingTop={8}
                  paddingBottom={8}
                  marginTop={0}
                  width={Dimensions.get('window').width / 3.4}
                  placeholder="Enter Price"
                  value={Rentprice}
                  onChangeText={v => setRentPrice(v)}
                  // autoFocus={true}
                  keyboardType="number-pad"
                />
                <View style={{width: 10}} />
                <PickerInput
                  width={Dimensions.get('window').width / 6.5}
                  data={data.map(v => ({label: v.time, value: v.time}))}
                  selected={time}
                  setSelected={setTime}
                  placeholder={'Time'}
                />
                <View style={{width: 10}} />
                <PickerInput
                  width={Dimensions.get('window').width / 6.5}
                  data={
                    time == 'Minutes'
                      ? Minute.map(v => ({label: v.time, value: v.time}))
                      : time == 'Houre'
                      ? hour.map(v => ({label: v.time, value: v.time}))
                      : time == 'Day'
                      ? Day.map(v => ({label: v.time, value: v.time}))
                      : time == 'Week'
                      ? Week.map(v => ({label: v.time, value: v.time}))
                      : time == 'Month'
                      ? month.map(v => ({label: v.time, value: v.time}))
                      : time == 'Year' &&
                        year.map(v => ({label: v.time, value: v.time}))
                  }
                  selected={timePeriod}
                  setSelected={setTimePeriod}
                  placeholder={time}
                />
              </View> */}
              <TouchableOpacity
                onPress={() => {
                  if (price == "") {
                    ShowToast("Please enter selected product price", "error");
                    return;
                  }
                  if (price < 1) {
                    ShowToast("Please enter selected product price", "error");
                    return;
                  }
                  if (Rentprice != "") {
                    setAll_Rent_Prices(v => v.concat(Rentprice));
                  }
                  if (all_Rent_Prices == null) {
                    setAll_Rent_Prices([]);
                  }
                  setAllPrices(v => v.concat(price));
                  setAll_Rent_timing(v => v.concat(time));
                  setAll_Rent_Period(v => v.concat(timePeriod));
                  setPrice("");
                  setTimePeriod("");
                  setRentPrice("");
                  setTime("");
                  setOnpress_In([]);
                  setOnpress_Out([]);
                  setModal(false);
                }}
                style={{
                  alignItems: "center",
                  width: Dimensions.get("window").width - 80,
                  marginTop: 10,
                  alignSelf: "center",
                  borderWidth: 0.5,
                  paddingVertical: 10,
                  borderColor: theme.colors.SubItem,
                  borderRadius: 5,
                }}>
                <TextFormated style={{fontSize: 16, fontWeight: "600"}}>
                  OK
                </TextFormated>
              </TouchableOpacity>
            </View>
          </TouchableOpacity>
        </TouchableOpacity>
      </Modal>

      <Modal
        animationType="slide"
        visible={modalThree}
        onDismiss={() => setModalThree(false)}
        transparent
        style={{}}>
        <TouchableOpacity
          onPress={() => setModalThree(false)}
          activeOpacity={1}
          style={{
            justifyContent: "flex-end",
            alignItems: "center",
            backgroundColor: "transparent",
            backgroundColor: theme.colors.Black + "33",
            width: Dimensions.get("window").width,
            height: Dimensions.get("window").height,
          }}>
          <TouchableOpacity
            activeOpacity={1}
            style={{
              backgroundColor: theme.colors.primary,
              width: Dimensions.get("window").width,
              height: Dimensions.get("window").width - 150,
              // alignItems: 'center',
              borderRadius: 20,
              // borderWidth: 0.4,
              // borderColor: theme.colors.Light_Gray,
            }}>
            <View
              style={{
                flex: 1,
                justifyContent: "center",
                borderRadius: 20,
                overflow: "hidden",
                alignItems: "center",
              }}>
              <View
                style={{
                  marginHorizontal: 20,
                  // borderWidth: 1,
                  alignItems: "center",
                  flexDirection: "row",
                  justifyContent: "space-between",
                  width: Dimensions.get("window").width / 2,
                }}>
                <TouchableOpacity
                  onPress={() => picCamera()}
                  style={{alignItems: "center"}}>
                  <Image
                    style={{height: 50, width: 50, resizeMode: "contain"}}
                    source={require("../../../../assets/Open_Camera.png")}
                  />
                  <TextFormated
                    style={{
                      fontSize: 16,
                      fontWeight: "600",
                      paddingVertical: 8,
                    }}>
                    Camera
                  </TextFormated>
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={() => pickImage()}
                  style={{alignItems: "center"}}>
                  <Image
                    style={{height: 50, width: 50, resizeMode: "contain"}}
                    source={require("../../../../assets/gallery.png")}
                  />
                  <TextFormated
                    style={{
                      fontSize: 16,
                      fontWeight: "600",
                      paddingVertical: 8,
                    }}>
                    Liabrary
                  </TextFormated>
                </TouchableOpacity>
              </View>
            </View>
            <View style={{marginHorizontal: 20, marginBottom: 15}}>
              <Button
                onPress={() => setModalThree(false)}
                ButtonText={"CANCEL"}
                paddingVertical={15}
              />
            </View>
          </TouchableOpacity>
        </TouchableOpacity>
      </Modal>

      <Modal
        animationType="fade"
        visible={modalTwo}
        onDismiss={() => setModalTwo(false)}
        transparent
        style={{}}>
        <TouchableOpacity
          onPress={() => setModalTwo(false)}
          activeOpacity={1}
          style={{
            justifyContent: "center",
            alignItems: "center",
            backgroundColor: "transparent",
            backgroundColor: theme.colors.Black + "33",
            width: Dimensions.get("window").width,
            height: Dimensions.get("window").height,
          }}>
          <TouchableOpacity
            activeOpacity={1}
            style={{
              backgroundColor: theme.colors.primary,
              width: Dimensions.get("window").width - 60,
              height: Dimensions.get("window").width - 130,
              alignItems: "center",
              borderRadius: 20,
              // borderWidth: 0.4,
              // borderColor: theme.colors.Light_Gray,
            }}>
            <View
              style={{
                flex: 1,
                justifyContent: "center",
                borderRadius: 20,
                overflow: "hidden",
                alignItems: "center",
              }}>
              <View
                style={{
                  marginHorizontal: 20,
                  // borderWidth: 1,
                  alignItems: "center",
                }}>
                <TextFormated
                  style={{
                    fontSize: 16,
                    fontWeight: "600",
                    paddingVertical: 20,
                  }}>
                  Style
                </TextFormated>
                <FlatList
                  data={Availablity}
                  numColumns={4}
                  contentContainerStyle={{}}
                  scrollEnabled={false}
                  renderItem={({item, index}) => (
                    <TouchableOpacity
                      onPress={() => {
                        // setSelected([]);
                        setSelected(prevState =>
                          prevState.find(v => item.title == v)
                            ? prevState.filter(v => item.title != v)
                            : [...prevState, item.title],
                        );
                      }}
                      style={{
                        backgroundColor: selected.find(v => v == item.title)
                          ? theme.colors.yellow
                          : theme.colors.SelectAvailablity,
                        shadowColor: "#000",
                        shadowOffset: {
                          width: 0,
                          height: 2,
                        },
                        shadowOpacity: 0.25,
                        shadowRadius: 3.84,

                        elevation: 5,
                        marginRight: 15,
                        alignItems: "center",
                        justifyContent: "center",

                        paddingVertical: 12,
                        flexDirection: "row",
                        borderRadius: 5,
                        width: Dimensions.get("window").width / 5,
                      }}>
                      <TextFormated
                        style={{
                          fontWeight: "700",
                          color: theme.colors.primary,
                          fontSize: 10,
                        }}>
                        {item.DisplayName}
                      </TextFormated>
                    </TouchableOpacity>
                  )}
                />
              </View>
            </View>

            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                marginBottom: 20,
              }}>
              <TouchableOpacity
                onPress={() => {
                  AddProduct();
                }}
                style={{
                  alignItems: "center",
                  justifyContent: "center",
                  paddingVertical: 15,
                  borderRadius: 6,
                  backgroundColor: theme.colors.green,
                  flex: 1,
                  shadowColor: "#000",
                  shadowOffset: {
                    width: 0,
                    height: 2,
                  },
                  shadowOpacity: 0.25,
                  shadowRadius: 3.84,

                  elevation: 5,
                  marginHorizontal: 15,
                }}>
                {loading ? (
                  <ActivityIndicator
                    size={"small"}
                    style={{margin: 2}}
                    color="#fff"
                  />
                ) : (
                  <TextFormated
                    style={{fontWeight: "700", color: theme.colors.primary}}>
                    OK
                  </TextFormated>
                )}
              </TouchableOpacity>
            </View>
          </TouchableOpacity>
        </TouchableOpacity>
      </Modal>
    </View>
  );
}

// /**
//  * Copyright (c) Facebook, Inc. and its affiliates.
//  *
//  * This source code is licensed under the MIT license found in the
//  * LICENSE file in the root directory of this source tree.
//  *
//  * @flow
//  */

// import React from 'react';
// import {
//   Image,
//   ScrollView,
//   StyleSheet,
//   Text,
//   TouchableHighlight,
//   View,
//   Platform,
// } from 'react-native';
// import ImageEditor from '@react-native-community/image-editor';

// const DEFAULT_IMAGE_HEIGHT = 720;
// const DEFAULT_IMAGE_WIDTH = 1080;

// type ImageOffset = {|
//   x: number,
//   y: number,
// |};

// type ImageSize = {|
//   width: number,
//   height: number,
// |};

// type ImageCropData = {|
//   offset: ImageOffset,
//   size: ImageSize,
//   displaySize?: ?ImageSize,
//   resizeMode?: ?any,
// |};

// export default class SquareImageCropper extends React.Component<
//   $FlowFixMeProps,
//   $FlowFixMeState,
// > {
//   state: any;
//   _isMounted: boolean;
//   _transformData: ImageCropData;

//   /* $FlowFixMe(>=0.85.0 site=react_native_fb) This comment suppresses an error
//    * found when Flow v0.85 was deployed. To see the error, delete this comment
//    * and run Flow. */
//   constructor(props) {
//     super(props);
//     this._isMounted = true;
//     this.state = {
//       photo: {
//         uri: `https://source.unsplash.com/2Ts5HnA67k8/${DEFAULT_IMAGE_WIDTH}x${DEFAULT_IMAGE_HEIGHT}`,
//         height: DEFAULT_IMAGE_HEIGHT,
//         width: DEFAULT_IMAGE_WIDTH,
//       },
//       measuredSize: null,
//       croppedImageURI: null,
//       cropError: null,
//     };
//   }

//   render() {
//     if (!this.state.measuredSize) {
//       return (
//         <View
//           style={styles.container}
//           onLayout={event => {
//             const measuredWidth = event.nativeEvent.layout.width;
//             if (!measuredWidth) {
//               return;
//             }
//             this.setState({
//               measuredSize: {width: measuredWidth, height: measuredWidth},
//             });
//           }}
//         />
//       );
//     }

//     if (!this.state.croppedImageURI) {
//       return this._renderImageCropper();
//     }
//     return this._renderCroppedImage();
//   }

//   _renderImageCropper() {
//     if (!this.state.photo) {
//       return <View style={styles.container} />;
//     }
//     let error = null;
//     if (this.state.cropError) {
//       error = <Text>{this.state.cropError.message}</Text>;
//     }
//     return (
//       <View style={styles.container}>
//         <Text style={styles.text} testID={'headerText'}>
//           Drag the image within the square to crop:
//         </Text>
//         <ImageCropper
//           image={this.state.photo}
//           size={this.state.measuredSize}
//           style={[styles.imageCropper, this.state.measuredSize]}
//           onTransformDataChange={data => (this._transformData = data)}
//         />
//         <TouchableHighlight
//           style={styles.cropButtonTouchable}
//           onPress={this._crop.bind(this)}>
//           <View style={styles.cropButton}>
//             <Text style={styles.cropButtonLabel}>Crop</Text>
//           </View>
//         </TouchableHighlight>
//         {error}
//       </View>
//     );
//   }

//   _renderCroppedImage() {
//     return (
//       <View style={styles.container}>
//         <Text style={styles.text}>Here is the cropped image:</Text>
//         <Image
//           source={{uri: this.state.croppedImageURI}}
//           style={[styles.imageCropper, this.state.measuredSize]}
//         />
//         <TouchableHighlight
//           style={styles.cropButtonTouchable}
//           onPress={this._reset.bind(this)}>
//           <View style={styles.cropButton}>
//             <Text style={styles.cropButtonLabel}>Try again</Text>
//           </View>
//         </TouchableHighlight>
//       </View>
//     );
//   }

//   async _crop() {
//     try {
//       const croppedImageURI = await ImageEditor.cropImage(
//         this.state.photo.uri,
//         this._transformData,
//       );

//       if (croppedImageURI) {
//         this.setState({croppedImageURI});
//       }
//     } catch (cropError) {
//       this.setState({cropError});
//     }
//   }

//   _reset() {
//     this.setState({
//       croppedImageURI: null,
//       cropError: null,
//     });
//   }
// }

// class ImageCropper extends React.Component<$FlowFixMeProps, $FlowFixMeState> {
//   _contentOffset: ImageOffset;
//   _maximumZoomScale: number;
//   _minimumZoomScale: number;
//   _scaledImageSize: ImageSize;
//   _horizontal: boolean;

//   UNSAFE_componentWillMount() {
//     // Scale an image to the minimum size that is large enough to completely
//     // fill the crop box.
//     const widthRatio = this.props.image.width / this.props.size.width;
//     const heightRatio = this.props.image.height / this.props.size.height;
//     this._horizontal = widthRatio > heightRatio;
//     if (this._horizontal) {
//       this._scaledImageSize = {
//         width: this.props.image.width / heightRatio,
//         height: this.props.size.height,
//       };
//     } else {
//       this._scaledImageSize = {
//         width: this.props.size.width,
//         height: this.props.image.height / widthRatio,
//       };
//       if (Platform.OS === 'android') {
//         // hack to work around Android ScrollView a) not supporting zoom, and
//         // b) not supporting vertical scrolling when nested inside another
//         // vertical ScrollView (which it is, when displayed inside UIExplorer)
//         this._scaledImageSize.width *= 2;
//         this._scaledImageSize.height *= 2;
//         this._horizontal = true;
//       }
//     }
//     this._contentOffset = {
//       x: (this._scaledImageSize.width - this.props.size.width) / 2,
//       y: (this._scaledImageSize.height - this.props.size.height) / 2,
//     };
//     this._maximumZoomScale = Math.min(
//       this.props.image.width / this._scaledImageSize.width,
//       this.props.image.height / this._scaledImageSize.height,
//     );
//     this._minimumZoomScale = Math.max(
//       this.props.size.width / this._scaledImageSize.width,
//       this.props.size.height / this._scaledImageSize.height,
//     );
//     this._updateTransformData(
//       this._contentOffset,
//       this._scaledImageSize,
//       this.props.size,
//     );
//   }

//   _onScroll(event) {
//     this._updateTransformData(
//       event.nativeEvent.contentOffset,
//       event.nativeEvent.contentSize,
//       event.nativeEvent.layoutMeasurement,
//     );
//   }

//   _updateTransformData(offset, scaledImageSize, croppedImageSize) {
//     const offsetRatioX = offset.x / scaledImageSize.width;
//     const offsetRatioY = offset.y / scaledImageSize.height;
//     const sizeRatioX = croppedImageSize.width / scaledImageSize.width;
//     const sizeRatioY = croppedImageSize.height / scaledImageSize.height;

//     const cropData: ImageCropData = {
//       offset: {
//         x: this.props.image.width * offsetRatioX,
//         y: this.props.image.height * offsetRatioY,
//       },
//       size: {
//         width: this.props.image.width * sizeRatioX,
//         height: this.props.image.height * sizeRatioY,
//       },
//     };
//     this.props.onTransformDataChange &&
//       this.props.onTransformDataChange(cropData);
//   }

//   render() {
//     return (
//       <ScrollView
//         alwaysBounceVertical={true}
//         automaticallyAdjustContentInsets={false}
//         contentOffset={this._contentOffset}
//         decelerationRate="fast"
//         horizontal={this._horizontal}
//         maximumZoomScale={this._maximumZoomScale}
//         minimumZoomScale={this._minimumZoomScale}
//         onMomentumScrollEnd={this._onScroll.bind(this)}
//         onScrollEndDrag={this._onScroll.bind(this)}
//         showsHorizontalScrollIndicator={false}
//         showsVerticalScrollIndicator={false}
//         style={this.props.style}
//         scrollEventThrottle={16}>
//         <Image
//           testID={'testImage'}
//           source={this.props.image}
//           style={this._scaledImageSize}
//         />
//       </ScrollView>
//     );
//   }
// }

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     alignSelf: 'stretch',
//     marginTop: 60,
//   },
//   imageCropper: {
//     alignSelf: 'center',
//     marginTop: 12,
//   },
//   cropButtonTouchable: {
//     alignSelf: 'center',
//     marginTop: 12,
//   },
//   cropButton: {
//     padding: 12,
//     backgroundColor: 'blue',
//     borderRadius: 4,
//   },
//   cropButtonLabel: {
//     color: 'white',
//     fontSize: 16,
//     fontWeight: '500',
//   },
//   text: {
//     color: 'white',
//   },
// });
