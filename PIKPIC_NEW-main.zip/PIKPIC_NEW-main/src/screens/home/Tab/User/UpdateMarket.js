import {useRoute} from "@react-navigation/native";
import moment from "moment";
import React, {useEffect, useState} from "react";
import {
  Dimensions,
  FlatList,
  Image,
  ImageBackground,
  StyleSheet,
  TouchableOpacity,
  useWindowDimensions,
  View,
} from "react-native";
import LinearGradient from "react-native-linear-gradient";
import {useSelector} from "react-redux";
import Header from "../../../../components/Header";
import LoadingSpinner from "../../../../components/LoadingSpinner";
import Statusbar from "../../../../components/Statusbar";
import {default as TextFormated} from "../../../../components/TextFormated";
import {baseUrl} from "../../../../utils/constance";
import {sendNotification} from "../../../../utils/funcs";
import {theme} from "../../../../utils/theme";
import {ShowToast} from "../../../../utils/ToastFunction";

export default function ShowCase({navigation, setGet_followed_event}) {
  const dimensions = useWindowDimensions();
  const auth = useSelector(state => state.auth);
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [isFocused, setIsFocused] = useState(true);
  const [id, setId] = useState([]);
  const [selectedProduct, setSelectedProduct] = useState([]);
  const {params} = useRoute();

  // alert(JSON.stringify(params?.selected_products?.length));
  // alert(
  //   JSON.stringify(moment(params?.closeTime).format('YYYY-MM-DD HH:mm:ss')),
  // );
  // console.log(id);
  console.log("selectedProduct", selectedProduct);
  // console.log('params', params?.maekrt_data?.market_name);

  async function LikeUnlike(id) {
    try {
      const url = baseUrl + "like_post?id=" + id + "&user_id=" + auth.id;
      console.log(url);

      const res = await fetch(url, {
        method: "GET",
        headers: {"Cache-Control": "no-cache"},
      });
      console.log(res);
      const rslt = await res.json();
      console.log(rslt);

      if (rslt.success == "1") {
        sendNotification({
          tokens: [user_id],
          title: "New Like",
          body: auth.name + " Like Your product",
        });
        GetProduct(true);
      } else {
        // ShowToast(rslt.message || 'Unknown error', 'error');
      }
    } catch (e) {
      // alert('An error occured.');
      ShowToast("An error occured.", "error");
      console.log(e);
    }
  }

  async function GetProduct(silent = false) {
    try {
      if (!silent) {
        setLoading(true);
      }
      const url = baseUrl + "get_post_product";
      const body = new FormData();
      body.append("user_id", auth.id);
      const res = await fetch(url, {
        method: "POST",
        body: body,
        headers: {
          "content-type": "multipart/form-data",
        },
      });
      console.log(res);
      const rslt = await res.json();
      console.log(rslt);

      if (rslt.success == "1") {
        setData(rslt.post_data.reverse());

        if (params?.selected_products?.length == 0) {
          rslt.post_data.forEach(item => {
            // setId(item.id);
            setSelectedProduct(prevState =>
              prevState.find(v => item.id == v)
                ? prevState.filter(v => item.id != v)
                : [...prevState, item.id],
            );
          });
        }

        if (!silent) {
          setLoading(false);
        }
        setRefreshing(false);
      } else {
        // // ShowToast(rslt.message || 'Unknown error', 'error');
        if (!silent) {
          setLoading(false);
        }
        setRefreshing(false);
      }
    } catch (e) {
      // alert('An error occured.');
      // ShowToast('An error occured.', 'error');
      if (!silent) {
        setLoading(false);
      }
      setRefreshing(false);

      console.log(e);
    }
  }

  async function UpdateMarket() {
    try {
      setLoading(true);
      const url = baseUrl + "update_market";

      console.log(url);

      const body = new FormData();
      body.append("market_id", params?.maekrt_data?.id);
      body.append("market_name", params?.maekrt_data?.market_name);
      body.append("duration", params?.maekrt_data?.duration);
      body.append("lat", params?.maekrt_data?.lat);
      body.append("long", params?.maekrt_data?.long);
      body.append("creator_user_id", auth.id);
      body.append("start_date_time", params?.maekrt_data?.start_date_time);
      body.append("end_date_time", params?.maekrt_data?.end_date_time);
      body.append("date", params?.maekrt_data?.date);
      body.append("timezone", params?.maekrt_data?.time_zone);
      body.append("date_time", params?.maekrt_data?.date_time);
      body.append("selected_products", selectedProduct.join(","));

      console.log(body);
      // return;

      const res = await fetch(url, {
        method: "POST",
        body: body,
        headers: {
          "content-type": "multipart/form-data",
        },
      });
      console.log(res);
      const rslt = await res.json();
      console.log(rslt);

      if (rslt.success == "1") {
        ShowToast("Market Update Successfully.");
        navigation.goBack();
        // sendNotification({
        //   tokens: params?.users,
        //   title: 'New Market',
        //   body: 'There is a market nearby',
        // });
      } else {
        // ShowToast(rslt.message || 'Unknown error', 'error');
      }
      setLoading(false);
    } catch (e) {
      setLoading(false);
      // alert('An error occured.');
      ShowToast("An error occured.", "error");

      console.log(e);
    }
  }

  const Removeval = () => {
    const selectedProduct = [...passcode];
    selectedProduct?.pop();
    setPasscode(selectedProduct);
    console.log("selectedProduct", selectedProduct);
  };

  useEffect(() => {
    GetProduct();
    setTimeout(() => {
      if (params?.selected_products?.length != 0) {
        params?.selected_products.forEach(item => {
          // setId(item.id);
          setSelectedProduct(prevState =>
            prevState.find(v => item.id == v)
              ? prevState.filter(v => item.id != v)
              : [...prevState, item.id],
          );
        });
      }
    }, 1000);
  }, []);

  useEffect(() => {
    const unsubscribe = navigation.addListener("focus", () => {
      GetProduct(true);
    });
    return unsubscribe;
  }, [navigation]);

  return (
    <View
      style={{
        flex: 1,
        backgroundColor: "#fff",
      }}>
      <LoadingSpinner
        textContent="Loading..."
        size={60}
        visible={loading}
        color={theme.colors.yellow}
      />

      <Statusbar
        barStyle="dark-content"
        backgroundColor={theme.colors.primary}
      />
      <Header
        navigation={navigation}
        Headertext={"Select Product"}
        sourcetwo={require("../../../../assets/Add.png")}
        tintColor={theme.colors.green}
        onPressTwo={() => navigation.navigate("AddProduct")}
      />
      <View
        style={{
          backgroundColor: "#fff",
          flex: 1,
        }}>
        <FlatList
          data={data}
          ListEmptyComponent={
            <View
              style={{
                flex: 1,
                alignItems: "center",
                backgroundColor: "#fff",
                justifyContent: "center",
              }}>
              <Image
                source={require("../../../../assets/gif/DataNotFound.gif")}
                style={{
                  height: dimensions.width / 1.5,
                  width: dimensions.width / 1.5,
                  resizeMode: "contain",
                  alignSelf: "center",
                  borderWidth: 3,
                  borderColor: theme.colors.primary,
                }}
              />
            </View>
          }
          numColumns={2}
          showsVerticalScrollIndicator={false}
          scrollEnabled={true}
          ItemSeparatorComponent={() => <View style={{width: 20}} />}
          renderItem={({item, index}) => (
            <TouchableOpacity
              onPress={() => {
                // if (selectedProduct?.filter(i => i == item.id)) {
                //   setSelectedProduct(v => [...v, item.id]);
                // }
                setSelectedProduct(prevState =>
                  prevState.find(v => item.id == v)
                    ? prevState.filter(v => item.id != v)
                    : [...prevState, item.id],
                );
              }}
              style={{
                backgroundColor: theme.colors.primary,
                marginHorizontal: 4,
                marginVertical: 4,
                borderWidth: 3,
                borderColor: selectedProduct?.find(v => v == item.id)
                  ? theme.colors.green
                  : theme.colors.primary,
              }}>
              <View
                style={{
                  backgroundColor: "transparent",
                  width: dimensions.width / 2.15,
                  height: dimensions.width / 2,
                  // borderRadius: 12,
                  overflow: "hidden",
                }}>
                <ImageBackground
                  source={{uri: item.image}}
                  style={{
                    width: dimensions.width / 2.15,
                    height: dimensions.width / 2,
                    backgroundColor: theme.colors.Tabbg,
                  }}
                  imageStyle={{
                    resizeMode: "cover",
                    // borderRadius: 12,
                  }}>
                  <View
                    style={{
                      position: "absolute",
                      right: 13,
                      top: 5,
                    }}></View>
                  <View
                    style={{
                      position: "absolute",
                      bottom: 0,
                      flexDirection: "row",
                      alignItems: "center",
                    }}>
                    {item?.like_status == "YES" && (
                      <TouchableOpacity
                        onPress={() => LikeUnlike(item.id.item.user_id)}
                        style={{flex: 1}}>
                        <LinearGradient
                          colors={[
                            theme.colors.Linear_first,
                            theme.colors.Linear_second,
                            theme.colors.Linear_third,
                          ]}
                          start={{x: 0.3, y: 0}}
                          end={{x: 0.5, y: 3.5}}
                          style={{
                            // width: Dimensions.get('window').width / 6.9,
                            alignItems: "center",
                            justifyContent: "center",
                            paddingVertical: 4,
                          }}>
                          <TextFormated
                            style={{
                              fontWeight: "500",
                              color: theme.colors.primary,
                              fontSize: 8,
                            }}>
                            LIKE {item?.like}
                          </TextFormated>
                        </LinearGradient>
                      </TouchableOpacity>
                    )}
                    {item.ask_status == "YES" && (
                      <TouchableOpacity
                        onPress={() => {}}
                        style={{
                          // width: Dimensions.get('window').width / 6.9,
                          alignItems: "center",
                          justifyContent: "center",
                          paddingVertical: 4,
                          backgroundColor: theme.colors.red,
                          flex: 1,
                        }}>
                        <TextFormated
                          style={{
                            fontWeight: "500",
                            color: theme.colors.primary,
                            fontSize: 8,
                          }}>
                          ASK
                        </TextFormated>
                      </TouchableOpacity>
                    )}
                    {item?.order_status == "YES" && (
                      <TouchableOpacity
                        onPress={() => {}}
                        style={{
                          // width: Dimensions.get('window').width / 6.9,
                          alignItems: "center",
                          justifyContent: "center",
                          paddingVertical: 4,
                          backgroundColor: theme.colors.purple,
                          flex: 1,
                        }}>
                        <TextFormated
                          style={{
                            fontWeight: "500",
                            color: theme.colors.primary,
                            fontSize: 8,
                          }}>
                          ORDER {item?.order}
                        </TextFormated>
                      </TouchableOpacity>
                    )}

                    {item.rent_status == "YES" && (
                      <TouchableOpacity
                        onPress={() => {}}
                        style={{
                          // width: Dimensions.get('window').width / 6.9,
                          alignItems: "center",
                          justifyContent: "center",
                          paddingVertical: 6,
                          backgroundColor: theme.colors.Chat_container,
                          flex: 1,
                        }}>
                        <TextFormated
                          style={{
                            fontWeight: "500",
                            color: theme.colors.primary,
                            fontSize: 10,
                          }}>
                          RENT
                        </TextFormated>
                      </TouchableOpacity>
                    )}
                  </View>
                </ImageBackground>
              </View>
            </TouchableOpacity>
          )}
        />
      </View>

      <TouchableOpacity
        onPress={() => {
          UpdateMarket();
        }}
        style={{
          // paddingVertical: 15,
          // paddingHorizontal: 15,
          // backgroundColor: theme.colors.green,
          borderRadius: 120,
          position: "absolute",
          bottom: 40,
          right: 20,
        }}>
        <Image
          style={{
            height: 55,
            width: 55,
            borderRadius: 120,
            resizeMode: "contain",
          }}
          source={require("../../../../assets/gif/next.gif")}
        />
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  name: {
    fontSize: 18,
    fontWeight: "700",
    width: "60%",
    color: theme.colors.Black,
  },
  header_image: {
    height: 33,
    width: 33,
    resizeMode: "contain",
  },
  title: {
    fontSize: 16,
    fontWeight: "700",
    width: "80%",
    color: theme.colors.Black,
  },
  ViewAll: {
    fontSize: 12,
    fontWeight: "700",
    color: theme.colors.Linear_second,
    textDecorationLine: "underline",
  },
  graph_image: {
    height: Dimensions.get("window").width / 2,
    width: Dimensions.get("window").width / 1,
    resizeMode: "cover",
  },
});
