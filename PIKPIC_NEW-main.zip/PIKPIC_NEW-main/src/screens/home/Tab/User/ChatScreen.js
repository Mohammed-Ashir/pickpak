import {useNavigation, useRoute} from "@react-navigation/native";
import moment from "moment";
import React, {useEffect, useState} from "react";
import {
  Dimensions,
  FlatList,
  Image,
  Modal,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import {ActivityIndicator} from "react-native-paper";
import Icon from "react-native-vector-icons/dist/MaterialCommunityIcons";
import {useSelector} from "react-redux";
import Header from "../../../../components/Header";
import Statusbar from "../../../../components/Statusbar";
import TextFormatted from "../../../../components/TextFormated";
import {baseUrl} from "../../../../utils/constance";
import {theme} from "../../../../utils/theme";
import {ShowToast} from "../../../../utils/ToastFunction";
import {sendNotification} from "../../../../utils/funcs";

const CHATS_DATA = [
  {
    user_name: "Dina Meyer",
    personId: "41",
    // image: require('../../../Assets/Clock.png'),
    message: "Hellow",
    isOwn: true,
    messageId: "1",
  },
  {
    user_name: "Ryan Joseph",
    personId: "2",
    // image: require('../../../Assets/Clock.png'),
    message: "How are you..?? ",
    isOwn: false,
    messageId: "2",
  },
  {
    user_name: "Dina Meyer",
    personId: "41",
    // image: require('../../../Assets/Clock.png'),
    message: "I am Fine",
    isOwn: true,
    messageId: "3",
  },
  {
    user_name: "Ryan Joseph",
    personId: "2",
    // image: require('../../../Assets/Clock.png'),
    message: "How are you..?? ",
    isOwn: false,
    messageId: "2",
  },
  {
    user_name: "Dina Meyer",
    personId: "41",
    // image: require('../../../Assets/Clock.png'),
    message: "I am Fine",
    isOwn: true,
    messageId: "3",
  },
  {
    user_name: "Ryan Joseph",
    personId: "2",
    // image: require('../../../Assets/Clock.png'),
    message: "How are you..?? ",
    isOwn: false,
    messageId: "2",
  },
  {
    user_name: "Dina Meyer",
    personId: "41",
    // image: require('../../../Assets/Clock.png'),
    message: "I am Fine",
    isOwn: true,
    messageId: "3",
  },
  {
    user_name: "Ryan Joseph",
    personId: "2",
    // image: require('../../../Assets/Clock.png'),
    message: "How are you..?? ",
    isOwn: false,
    messageId: "2",
  },
  {
    user_name: "Dina Meyer",
    personId: "41",
    // image: require('../../../Assets/Clock.png'),
    message: "I am Fine",
    isOwn: true,
    messageId: "3",
  },
  {
    user_name: "Ryan Joseph",
    personId: "2",
    // image: require('../../../Assets/Clock.png'),
    message: "How are you..?? ",
    isOwn: false,
    messageId: "2",
  },
  {
    user_name: "Dina Meyer",
    personId: "41",
    // image: require('../../../Assets/Clock.png'),
    message:
      "I am Finevodfbvdfgbfbfgbnkjngdfghghdkfhhdfjkhfkhfdhjkdkdfjkdfkfjkdfdjkdfkvdfjkdfjkjkfkddkkldjkdjkghdjk",
    isOwn: true,
    messageId: "3",
  },
].reverse();

function Chat(props) {
  const [CHATS, setChats] = useState(CHATS_DATA);
  const [messagesending, setMessagesending] = useState(false);
  const [messagetextinput, setMessagetextinput] = useState("");
  const [messageloading, setMessageloading] = useState(true);
  const [messages, setMessages] = useState([]);
  const navigation = useNavigation();
  const {params} = useRoute();
  const auth = useSelector(state => state.auth);
  const [loading, setLoading] = useState(false);
  // console.log("paramsparams", params);
  const [show, setShow] = useState(false);
  const [msg_ID, setMsg_ID] = useState("");

  // alert(JSON.stringify(params.id));

  async function SendMessage() {
    if (messagetextinput == "") {
      ShowToast("Please type something...");
      return;
    }
    try {
      setMessagesending(true);
      const url = baseUrl + "insert_chat";

      const body = new FormData();
      body.append("chat_sender_id", auth?.id);
      body.append("chat_receiver_id", params?.user_id);
      body.append("chat_message", messagetextinput);
      body.append(
        "chat_sender_timezone",
        Intl.DateTimeFormat().resolvedOptions().timeZone,
      );
      body.append("chat_date_time_of_sender_time_zone", new Date());
      // body.append("other_user_id", params?.owner_id);

      console.log("bodybody", body);
      // return;

      setMessagesending(true);
      const res = await fetch(url, {
        method: "POST",
        body: body,
        headers: {
          "content-type": "multipart/form-data",
          "Cache-Control": "no-cache",
        },
      });
      const rslt = await res.json();
      console.log(rslt);

      if (rslt.status == "1") {
        setMessagesending(false);
        setMessagetextinput("");
        Conversations();
        sendNotification({
          tokens: [params?.user_id],
          title: "New message in order no. " + params.id,
          body: messagetextinput,
        });
      } else {
        ShowToast(rslt.message || "Unknown error");
      }
      setMessagesending(false);
    } catch (e) {
      setMessagesending(false);
      ShowToast("An error occured.", "error");
    }
  }

  async function Conversations() {
    try {
      // setLoading(true);
      const url = baseUrl + "get_chat_between";

      const body = new FormData();
      body.append("user_id", auth?.id);
      body.append("other_user_id", params?.user_id);
      // body.append("other_user_id", "2");

      console.log("bodybody", body);
      // return;

      setLoading(true);
      const res = await fetch(url, {
        method: "POST",
        body: body,
        headers: {
          "content-type": "multipart/form-data",
          "Cache-Control": "no-cache",
        },
      });
      // console.log(res);
      const rslt = await res.json();
      console.log(rslt);

      if (rslt.status == "1") {
        setMessages(rslt.result);
      } else {
        ShowToast(rslt.result || rslt.message || "Unknown error");
      }
      setLoading(false);
    } catch (e) {
      setLoading(false);
      ShowToast("An error occured.", "error");
    }
  }

  async function DeleteMessage() {
    try {
      // setLoading(true);
      const url = baseUrl + "delete_chat";

      const body = new FormData();
      body.append("chat_id", msg_ID);

      console.log("delete_chat_body", body);

      setLoading(true);
      const res = await fetch(url, {
        method: "POST",
        body: body,
        headers: {
          "content-type": "multipart/form-data",
          "Cache-Control": "no-cache",
        },
      });
      // console.log(res);
      const rslt = await res.json();
      console.log(rslt);

      if (rslt.status == "1") {
        setShow(false);
        setMsg_ID("");
        Conversations();
        ShowToast("Message Deleted Successfully");
      } else {
        ShowToast(rslt.result || rslt.message || "Unknown error");
      }
      setLoading(false);
    } catch (e) {
      setLoading(false);
      ShowToast("An error occured.", "error");
    }
  }

  useEffect(() => {
    Conversations();
  }, []);

  return (
    <View
      style={{
        flex: 1,
        backgroundColor: "#fff",
        justifyContent: "space-between",
      }}>
      <Statusbar backgroundColor="#fff" barStyle="dark-content" />

      <Header navigation={navigation} Headertext={"Chat"} />

      <FlatList
        showsVerticalScrollIndicator={false}
        data={messages}
        ListEmptyComponent={
          <View
            style={{
              backgroundColor: theme.colors.primary,
              height: Dimensions.get("window").height / 1.2,
              alignItems: "center",
              justifyContent: "center",
            }}>
            <ActivityIndicator
              size={"large"}
              style={{}}
              color={theme.colors.yellow}
            />
          </View>
        }
        inverted
        renderItem={({item, index}) => {
          return (
            <View
              style={{
                alignItems:
                  item.chat_sender_id == auth?.id ? "flex-end" : "flex-start",
                marginTop: 20,
                flex: 1,
                // borderWidth: 1,
                // borderRadius: 20,
              }}>
              <TouchableOpacity
                activeOpacity={1}
                onLongPress={() => {
                  if (item.chat_sender_id == auth?.id) {
                    setShow(true);
                    setMsg_ID(item.chat_id);
                  }
                }}
                style={[
                  styles.SamePerson,
                  {
                    flexDirection:
                      item.chat_sender_id == auth?.id ? "row" : "row-reverse",
                    // borderWidth: 1,
                    shadowColor: "#000",
                    shadowOffset: {
                      width: 0,
                      height: 2,
                    },
                    shadowOpacity: 0.25,
                    shadowRadius: 3.84,

                    elevation: 5,
                    backgroundColor:
                      item.chat_sender_id == auth?.id
                        ? theme.colors.yellow
                        : "#fff",
                    // borderWidth: 1,

                    borderTopLeftRadius:
                      item.chat_sender_id == auth?.id ? 8 : 0,
                    borderTopRightRadius:
                      item.chat_sender_id == auth?.id ? 0 : 8,
                    borderBottomLeftRadius: 8,
                    borderBottomRightRadius: 8,
                  },
                ]}>
                <View
                  style={{
                    alignItems:
                      item.chat_sender_id == auth?.id
                        ? "flex-start"
                        : "flex-end",
                    maxWidth: "85%",
                  }}>
                  <View style={[styles.msg_Container, {}]}>
                    <TextFormatted
                      style={{
                        color:
                          item.chat_sender_id == auth?.id ? "#fff" : "#000",
                        fontWeight: "500",
                      }}>
                      {item.chat_message}
                    </TextFormatted>
                    <Text
                      style={[
                        styles.time,
                        {
                          color:
                            item.chat_sender_id == auth?.id
                              ? "#EBEBEB"
                              : "#7A7A7A",
                          fontWeight: "500",
                        },
                      ]}>
                      sender time:
                      {moment(item.show_this_time_in_app).format("LT")}
                    </Text>
                  </View>
                </View>
              </TouchableOpacity>
            </View>
          );
        }}
      />

      <View
        style={{
          backgroundColor: "#fff",
          flexDirection: "row",
          justifyContent: "space-between",
          alignItems: "center",
          paddingHorizontal: 15,
          paddingTop: 20,
          paddingBottom: 30,
        }}>
        <TextInput
          maxHeight={100}
          multiline={true}
          placeholder="Type a Message"
          style={{flex: 1}}
          value={messagetextinput}
          onChangeText={setMessagetextinput}
        />
        {messagesending ? (
          <ActivityIndicator color={theme.colors.yellow} />
        ) : (
          <TouchableOpacity onPress={() => SendMessage()}>
            <Image
              style={{height: 22, width: 22, resizeMode: "contain"}}
              source={require("../../../../assets/send.png")}
            />
          </TouchableOpacity>
        )}
      </View>

      <Modal
        animationType="fade"
        visible={show}
        onDismiss={() => {
          setShow(false);
        }}
        transparent
        style={{}}>
        <TouchableOpacity
          activeOpacity={1}
          style={{
            justifyContent: "center",
            alignItems: "center",
            backgroundColor: "transparent",
            backgroundColor: theme.colors.Black + "33",
            width: Dimensions.get("window").width,
            height: Dimensions.get("window").height,
          }}>
          <TouchableOpacity
            activeOpacity={1}
            style={{
              backgroundColor: theme.colors.primary,
              width: Dimensions.get("window").width - 120,
              height: Dimensions.get("window").width - 300,
              // height: Dimensions.get('window').width - 100,
              alignItems: "center",
              borderRadius: 20,
              // borderWidth: 0.4,
              // borderColor: theme.colors.Light_Gray,
              marginBottom: 45,
              justifyContent: "center",
            }}>
            <View
              style={{
                justifyContent: "flex-start",
                alignItems: "center",
                backgroundColor: theme.colors.primary,
                height: 120,
                width: Dimensions.get("window").width - 130,
                borderRadius: 10,
                paddingHorizontal: 15,
                // borderWidth: 1,
              }}>
              <TextFormatted
                style={{
                  color: theme.colors.Black,
                  marginVertical: 20,
                  fontSize: 12,
                  fontWeight: "700",
                  textAlign: "center",
                }}>
                Are you sure you want to delete this message?
              </TextFormatted>

              <View
                style={{
                  justifyContent: "space-between",
                  alignItems: "center",
                  flexDirection: "row",
                  paddingHorizontal: 15,
                  width: "80%",
                }}>
                <TouchableOpacity
                  onPress={() => {
                    setShow(false);
                    setMsg_ID("");
                  }}>
                  <TextFormatted
                    style={{
                      color: theme.colors.Black,
                      marginVertical: 20,
                      fontSize: 12,
                      fontWeight: "600",
                    }}>
                    Cancel
                  </TextFormatted>
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={() => {
                    DeleteMessage();
                  }}>
                  {loading ? (
                    <ActivityIndicator
                      size={"small"}
                      style={{}}
                      color={theme.colors.red}
                    />
                  ) : (
                    <TextFormatted
                      style={{
                        color: theme.colors.red,
                        marginVertical: 20,
                        fontSize: 12,
                        fontWeight: "600",
                      }}>
                      Sure
                    </TextFormatted>
                  )}
                </TouchableOpacity>
              </View>
            </View>
          </TouchableOpacity>
        </TouchableOpacity>
      </Modal>
    </View>
  );
}

export default Chat;

const styles = StyleSheet.create({
  Conversation_start_container: {
    flexDirection: "row",
    // width: '100%',
    marginTop: 10,
    alignItems: "center",
    justifyContent: "space-evenly",
    marginHorizontal: 30,
  },
  Conversation_start_Text: {
    fontSize: 15,
    fontFamily: Platform.OS == "android" ? "Poppins-SemiBold" : null,
    fontWeight: "700",
  },
  SamePerson: {
    alignItems: "center",
    marginBottom: 5,
    marginHorizontal: 20,
  },
  msg_Container: {
    borderRadius: 8,
    paddingHorizontal: 20,
    paddingVertical: 10,
    // elevation: 10,
    // borderWidth: 1,
  },
  time: {
    alignSelf: "flex-end",
    fontSize: 10,
    marginTop: 5,
  },
});
