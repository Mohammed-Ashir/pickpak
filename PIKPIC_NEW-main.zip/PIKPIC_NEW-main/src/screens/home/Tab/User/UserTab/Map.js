import moment from "moment";
import React, {useEffect, useRef, useState} from "react";
import {
  ActivityIndicator,
  Alert,
  Dimensions,
  Image,
  ImageBackground,
  Keyboard,
  KeyboardAvoidingView,
  Modal,
  ScrollView,
  TouchableOpacity,
  View,
} from "react-native";
import DatePicker from "react-native-date-picker";
import MapView, {Circle, Marker, PROVIDER_GOOGLE} from "react-native-maps";
import {useSelector} from "react-redux";
import Statusbar from "../../../../../components/Statusbar";
import TextFormated from "../../../../../components/TextFormated";
import CustomTextInput from "../../../../../components/TextInput";
import {baseUrl} from "../../../../../utils/constance";
import {theme} from "../../../../../utils/theme";
import {ShowToast} from "../../../../../utils/ToastFunction";
import LoadingSpinner from "../../../../../components/LoadingSpinner";
import RNLocation from "react-native-location";
import Geolocation from "@react-native-community/geolocation";
import dynamicLinks from "@react-native-firebase/dynamic-links";
import {Share} from "react-native";

const MARKERS = [
  {latitude: 22.761794329667982, longitude: 75.88739432394505},
  {latitude: 22.761794329667982, longitude: 75.89292671531439},
  {latitude: 22.757228500578126, longitude: 75.89016135782003},
  {latitude: 22.75746563806522, longitude: 75.88488578796387},
  {latitude: 22.752597898978536, longitude: 75.88765282183886},
  {latitude: 22.753667060297012, longitude: 75.8931852132082},
  {latitude: 22.718897408101107, longitude: 75.87684486061335},
  {latitude: 22.721981027815573, longitude: 75.87356217205524},
  {latitude: 22.71557217938178, longitude: 75.87382100522517},
  {latitude: 22.711539550780383, longitude: 75.87684486061335},
  {latitude: 22.71842299890038, longitude: 75.86970280855894},
  {latitude: 22.712013983840972, longitude: 75.87053831666708},
];

const screen = Dimensions.get("window");
const ASPECT_RATIO = screen.width / screen.height;
const LATITUDE_DELTA = 0.0029;
const LONGITUDE_DELTA = LATITUDE_DELTA * ASPECT_RATIO;
const LATITUDE_DELTA_TWO = 0.000001;
const LONGITUDE_DELTA_TWO = LATITUDE_DELTA_TWO * ASPECT_RATIO;

export default function MapSearch({
  navigation,
  MapId,
  MapBaseID,
  TappedOnMapDetail,
}) {
  const [Add, setAdd] = useState(false);
  const [selectedLat, setSelectedLat] = useState();
  const [selectedLon, setSelectedLon] = useState();
  const [modal, setModal] = useState(false);
  const [open, setOpen] = useState(false);
  const [date, setDate] = useState(new Date());
  const [loading, setLoading] = useState(false);
  const [loading_2, setLoading_2] = useState(false);
  const [Modal_2, setModal_2] = useState(false);
  const [Modal_3, setModal_3] = useState(false);
  const [openTime, setOpenTime] = useState();
  const [openTime_1, setOpenTime_1] = useState(false);
  const [closeTime, setCloseTime] = useState();
  const [closeTime_2, setCloseTime_2] = useState(false);
  const auth = useSelector(state => state.auth);
  const [setSinglemarketdata, setSetSinglemarketdata] = useState();
  const [market_name, setMarket_name] = useState("Open Market");
  const [isFocused, setIsFocused] = useState(true);
  const [joined, setJoined] = useState(false);
  const [deleted, setDeleted] = useState(false);
  const [Leave, setLeave] = useState(false);
  const [location, setLocation] = useState("");
  const [latitude, setLatitude] = useState(0);
  const [longitude, setLongitude] = useState(0);
  const [data, setData] = useState();
  const [UsersAroundUs, setUsersAroundUs] = useState([]);
  const [GenerateLink, setGenerateLink] = useState("");
  const [modalThree, setModalThree] = useState(false);
  const [pinCreate, setpinCreate] = useState(false);
  const [selectedLat_pin, setSelectedLat_pin] = useState();
  const [selectedLon_pin, setSelectedLon_pin] = useState();
  const [isKeyboardVisible, setKeyboardVisible] = useState(false);
  const [PinCreationAnimat, setPinCreationAnimat] = useState(false);
  const [SingleAnteenaData, setSingleAnteenaData] = useState();
  const [PinName, setPinName] = useState("");
  const [PinDeleteLoading, setPinDeleteLoading] = useState(false);
  // alert(SingleAnteenaData?.creator_user_id);
  // console.log(isKeyboardVisible);

  useEffect(() => {
    const keyboardDidShowListener = Keyboard.addListener(
      "keyboardDidShow",
      () => {
        setKeyboardVisible(true); // or some other action
      },
    );
    const keyboardDidHideListener = Keyboard.addListener(
      "keyboardDidHide",
      () => {
        setKeyboardVisible(false); // or some other action
      },
    );

    return () => {
      keyboardDidHideListener.remove();
      keyboardDidShowListener.remove();
    };
  }, []);

  function addSomeMinutesToTime(time) {
    setCloseTime();
    const dateObj = new Date(openTime?.toISOString());
    const newDateInNumber = dateObj.setMinutes(dateObj.getMinutes() + 10);
    const processedTime = new Date(newDateInNumber);
    console.log("processedTime", processedTime);
    return setCloseTime(processedTime);
  }

  useEffect(() => {
    addSomeMinutesToTime();
  }, [openTime]);

  const [SingleMarketDtata, setSingleMarketDtata] = useState();

  const [AllAnteena, setAllAnteena] = useState([]);

  // alert(JSON.stringify(moment(timingbchds).format('LT')));

  const Delete_Confirmation = id => {
    return Alert.alert(
      "Delete Pin! " + id,
      "Are you sure you want to delete thi pin?",
      [
        {
          text: "Yes",
          onPress: () => {
            DeletePin(id);
            OneSignal.removeExternalUserId();
          },
        },
        {text: "No"},
      ],
    );
  };

  const mapRef = useRef();

  async function GetPin() {
    try {
      const url = baseUrl + "get_all_antenna";
      console.log(url);

      const res = await fetch(url, {
        method: "GET",
        headers: {
          "content-type": "multipart/form-data",
        },
      });
      // console.log(res);
      const rslt = await res.json();
      // console.log(rslt);
      if (rslt.success == "1") {
        setAllAnteena(rslt.market_data);
      } else {
      }
    } catch (e) {
      // ShowToast('An error occured.', 'error');
      console.log(e);
    }
  }

  async function GetMarkets(silent = false) {
    try {
      if (!silent) {
        setLoading(true);
      }
      const url = baseUrl + "get_all_market";
      console.log(url);

      const res = await fetch(url, {
        method: "GET",
        headers: {
          "content-type": "multipart/form-data",
        },
      });
      // console.log(res);
      const rslt = await res.json();
      // console.log(rslt);

      if (rslt.success == "1") {
        setData(rslt.market_data);

        if (!silent) {
          setLoading(false);
        }
      } else {
        if (!silent) {
          setLoading(false);
        }
        // ShowToast(rslt.message || 'Unknown error', 'error');
        setData([]);
      }
    } catch (e) {
      if (!silent) {
        setLoading(false);
      } // alert('An error occured.');
      // ShowToast('An error occured.', 'error');
      console.log(e);
    }
  }

  async function GetMarketByID(silent = false) {
    try {
      if (!silent) {
        setLoading(true);
      }
      const url = baseUrl + "get_all_market";
      console.log(url);

      const res = await fetch(url, {
        method: "GET",
        headers: {
          "content-type": "multipart/form-data",
        },
      });
      // console.log(res);
      const rslt = await res.json();
      // console.log(rslt);

      if (rslt.success == "1") {
        setData(rslt.market_data);

        rslt.market_data.forEach(item => {
          if (item.id == MapId) {
            setSetSinglemarketdata(item);
            if (!SingleMarketDtata) {
              // setModal_2(true);
              console.log("SingleMarketDtata", item?.lat, item?.long);
              mapRef?.current?.animateToRegion({
                latitude: item?.lat || 0,
                longitude: item?.long || 0,
                latitudeDelta: LATITUDE_DELTA_TWO,
                longitudeDelta: LONGITUDE_DELTA_TWO,
              });
            }
          }
        });

        rslt.market_data.forEach(item => {
          if (item.id == MapBaseID) {
            setSetSinglemarketdata(item);
            if (!SingleMarketDtata) {
              // setModal_2(true);
              console.log("SingleMarketDtata", item);
              mapRef?.current?.animateToRegion({
                latitude: item?.lat || 0,
                longitude: item?.long || 0,
                latitudeDelta: LATITUDE_DELTA_TWO,
                longitudeDelta: LONGITUDE_DELTA_TWO,
              });
            }
          }
        });

        if (!silent) {
          setLoading(false);
        }
      } else {
        if (!silent) {
          setLoading(false);
        } // // ShowToast(rslt.message || 'Unknown error', 'error');
      }
    } catch (e) {
      if (!silent) {
        setLoading(false);
      } // alert('An error occured.');
      // ShowToast('An error occured.', 'error');
      console.log(e);
    }
  }

  async function GetUsersAroudUs() {
    try {
      const url =
        baseUrl +
        "get_user_by_radius?radius=10000&lat=" +
        latitude +
        "&long=" +
        longitude;
      console.log(url);

      const res = await fetch(url, {
        method: "GET",
        headers: {
          "content-type": "application/json",
        },
      });
      console.log("get_user_by_radius", res);
      const rslt = await res.json();
      console.log("get_user_by_radius", rslt);

      if (rslt.success == "1") {
        setUsersAroundUs(rslt.user_data);
      } else {
        // // ShowToast(rslt.message || 'Unknown error', 'error');
      }
    } catch (e) {
      console.log(e);
    }
  }

  async function DeleteMarket(id) {
    setLoading_2(true);
    try {
      const url = baseUrl + "delete_market";

      const body = new FormData();
      body.append("market_id", id);

      console.log(body);

      const res = await fetch(url, {
        method: "POST",
        body: body,
        headers: {
          "content-type": "multipart/form-data",
        },
      });
      console.log(res);
      const rslt = await res.json();
      console.log(rslt);

      if (rslt.success == "1") {
        setDeleted(true);
        GetMarkets(true);
        setTimeout(() => {
          setDeleted(false);
          setModal_2(false);
        }, 1800);
      } else {
        // ShowToast(rslt.message || 'Unknown error', 'error');
      }
      setLoading_2(false);
    } catch (e) {
      setLoading_2(false);
      // alert('An error occured.');
      ShowToast("An error occured.", "error");

      console.log(e);
    }
  }

  async function DeletePin(id) {
    try {
      setPinDeleteLoading(true);
      const url = baseUrl + "delete_antenna";

      const body = new FormData();
      body.append("antenna_id", SingleAnteenaData?.id);

      console.log(body);

      const res = await fetch(url, {
        method: "POST",
        body: body,
        headers: {
          "content-type": "multipart/form-data",
        },
      });
      console.log(res);
      const rslt = await res.json();
      console.log(rslt);

      if (rslt.success == "1") {
        setPinCreationAnimat(true);
        GetMarkets(true);
        setpinCreate(true);

        setTimeout(() => {
          setPinCreationAnimat(false);
          setpinCreate(false);
          setModalThree(false);
        }, 1800);
      } else {
        // ShowToast(rslt.message || 'Unknown error', 'error');
      }
      setPinDeleteLoading(false);
    } catch (e) {
      setPinDeleteLoading(false);
      // alert('An error occured.');
      ShowToast("An error occured.", "error");

      console.log(e);
    }
  }

  async function CreatePin() {
    try {
      setLoading(true);
      const url = baseUrl + "create_antenna";

      const body = new FormData();
      body.append("creator_user_id", auth?.id);
      body.append("lat", selectedLat_pin);
      body.append("long", selectedLon_pin);
      body.append("name", PinName);

      console.log(body);

      const res = await fetch(url, {
        method: "POST",
        body: body,
        headers: {
          "content-type": "multipart/form-data",
        },
      });
      console.log(res);
      const rslt = await res.json();
      console.log(rslt);

      if (rslt.success == "1") {
        ShowToast("Pin Created Successfully");
        setPinCreationAnimat(true);
        setpinCreate(false);
        setSelectedLat_pin();
        setSelectedLon_pin();
        setPinName();
        setTimeout(() => {
          setModalThree(false);
          setpinCreate(true);
          setPinCreationAnimat(false);
        }, 1800);
        GetPin();
      } else {
        // ShowToast(rslt.message || 'Unknown error', 'error');
      }
      setLoading(false);
    } catch (e) {
      setLoading(false);
      // alert('An error occured.');
      ShowToast("An error occured.", "error");

      console.log(e);
    }
  }

  async function JoinMarket(id) {
    try {
      setLoading(true);
      const url = baseUrl + "join_market";

      const body = new FormData();
      body.append("user_id", auth?.id);
      body.append("market_id", id);

      console.log(body);

      const res = await fetch(url, {
        method: "POST",
        body: body,
        headers: {
          "content-type": "multipart/form-data",
        },
      });
      console.log(res);
      const rslt = await res.json();
      console.log(rslt);

      if (rslt.success == "1") {
        setJoined(true);
        setTimeout(() => {
          setJoined(false);
          setModal_2(false);
          GetMarkets(true);
        }, 1800);
      } else {
        // ShowToast(rslt.message || 'Unknown error', 'error');
      }
      setLoading(false);
    } catch (e) {
      setLoading(false);
      // alert('An error occured.');
      ShowToast("An error occured.", "error");

      console.log(e);
    }
  }

  async function LeaveMarket(id) {
    try {
      setLoading(true);
      const url = baseUrl + "leave_market";

      const body = new FormData();
      body.append("user_id", auth?.id);
      body.append("market_id", id);

      console.log(body);

      const res = await fetch(url, {
        method: "POST",
        body: body,
        headers: {
          "content-type": "multipart/form-data",
        },
      });
      console.log(res);
      const rslt = await res.json();
      console.log(rslt);

      if (rslt.success == "1") {
        setLeave(true);
        setDeleted(true);
        setTimeout(() => {
          setLeave(false);
          setDeleted(false);
          setModal_2(false);
          GetMarkets(true);
        }, 1800);
      } else {
        // ShowToast(rslt.message || 'Unknown error', 'error');
      }
      setLoading(false);
    } catch (e) {
      setLoading(false);
      // alert('An error occured.');
      ShowToast("An error occured.", "error");

      console.log(e);
    }
  }

  async function UpdateMarket_Lat_Long(id, lat, long) {
    try {
      setLoading(true);
      const url = baseUrl + "update_market_lat_long";

      const body = new FormData();
      body.append("market_id", id);
      body.append("lat", lat);
      body.append("long", long);

      console.log(body);

      const res = await fetch(url, {
        method: "POST",
        body: body,
        headers: {
          "content-type": "multipart/form-data",
        },
      });
      console.log(res);
      const rslt = await res.json();
      console.log(rslt);

      if (rslt.success == "1") {
        GetMarkets(true);
        ShowToast("Market Coordinate Change Successfully");
      } else {
        // ShowToast(rslt.message || 'Unknown error', 'error');
      }
      setLoading(false);
    } catch (e) {
      setLoading(false);
      // alert('An error occured.');
      ShowToast("An error occured.", "error");

      console.log(e);
    }
  }

  async function UpdateAnteena_Lat_Long(id, lat, long) {
    try {
      setLoading(true);
      const url = baseUrl + "update_antenna_lat_long";

      const body = new FormData();
      body.append("antenna_id", id);
      body.append("lat", lat);
      body.append("long", long);

      console.log(body);

      const res = await fetch(url, {
        method: "POST",
        body: body,
        headers: {
          "content-type": "multipart/form-data",
        },
      });
      console.log(res);
      const rslt = await res.json();
      console.log(rslt);

      if (rslt.success == "1") {
        GetMarkets(true);
        ShowToast("Anteena Coordinate Change Successfully");
      } else {
        // ShowToast(rslt.message || 'Unknown error', 'error');
      }
      setLoading(false);
    } catch (e) {
      setLoading(false);
      // alert('An error occured.');
      ShowToast("An error occured.", "error");

      console.log(e);
    }
  }

  async function UpdateAnteena_Name() {
    try {
      setLoading(true);
      const url = baseUrl + "update_antenna_name";

      const body = new FormData();
      body.append("antenna_id", SingleAnteenaData?.id);
      body.append("name", PinName);

      console.log(body);

      const res = await fetch(url, {
        method: "POST",
        body: body,
        headers: {
          "content-type": "multipart/form-data",
        },
      });
      console.log(res);
      const rslt = await res.json();
      console.log(rslt);

      if (rslt.success == "1") {
        GetMarkets(true);
        GetPin(true);
        setModalThree(false);
        ShowToast("Anteena Name Updated Successfully");
      } else {
        // ShowToast(rslt.message || 'Unknown error', 'error');
      }
      setLoading(false);
    } catch (e) {
      setLoading(false);
      // alert('An error occured.');
      ShowToast("An error occured.", "error");

      console.log(e);
    }
  }

  const currentLocation = async () => {
    await RNLocation.requestPermission({
      ios: "whenInUse",
      android: {
        detail: "coarse",
      },
    });
    Geolocation.getCurrentPosition(async info => {
      setLongitude(info.coords.longitude);
      setLatitude(info.coords.latitude);
      console.log(longitude, latitude);

      // ShowToast(JSON.stringify(info.coords));
      const url =
        "https://maps.googleapis.com/maps/api/geocode/json?latlng=" +
        info.coords.latitude +
        "," +
        info.coords.longitude +
        "&key=AIzaSyCVPhg-esZszRMKtmkfSixhM4aykhYyeas";
      // '&key=AIzaSyCddyEDdSxzb2PYhyhy3K1GLY_ANspWc0s';

      setLongitude(info.coords.longitude);
      setLatitude(info.coords.latitude);

      console.log(url);
      try {
        // setLoading(true);
        const res = await fetch(url);
        console.log(res);

        const json = await res.json();
        console.log(json);
        setLocation(json.results[0]?.formatted_address);
      } catch (e) {
        // setLoading(false);
        ShowToast(e.toString());
      }
    }, console.warn);
  };

  const current_LAt_Long = async () => {
    await RNLocation.requestPermission({
      ios: "whenInUse",
      android: {
        detail: "coarse",
      },
    });
    Geolocation.getCurrentPosition(async info => {
      setLongitude(info.coords.longitude);
      setLatitude(info.coords.latitude);

      // setTimeout(() => {
      mapRef?.current?.animateToRegion({
        latitude: info?.coords?.latitude || 0,
        longitude: info?.coords?.longitude || 0,
        latitudeDelta: LATITUDE_DELTA,
        longitudeDelta: LONGITUDE_DELTA,
      });
      // }, 300);
      console.log(longitude, latitude);
    }, console.warn);
  };

  useEffect(() => {
    setTimeout(() => {
      currentLocation();
      GetUsersAroudUs();
    }, 1000);
    GetMarkets(true);
    GetPin();
    current_LAt_Long();
  }, []);

  useEffect(() => {
    const int = setInterval(() => {
      if (isFocused) {
        GetMarkets(true);
        GetPin();
      }
    }, 5000);
    return () => clearInterval(int);
  }, [isFocused]);

  useEffect(() => {
    const unsubscribe = navigation.addListener("focus", () => {
      setAdd(false);
      GetUsersAroudUs();
    });
    return unsubscribe;
  }, [navigation]);

  const onShare = async () => {
    try {
      const result = await Share.share({
        message: "Please Check This Out " + GenerateLink,
      });
      if (result.action === Share.sharedAction) {
        if (result.activityType) {
          // shared with activity type of result.activityType
        } else {
          // shared
        }
      } else if (result.action === Share.dismissedAction) {
        // dismissed
      }
    } catch (error) {
      alert(error.message);
    }
  };

  const buildLink = async () => {
    const link = await dynamicLinks().buildLink({
      link: "https://invertase.io/offer",
      domainUriPrefix: "https://pikpic.page.link",
      analytics: {
        campaign: "banner",
      },
    });
    setGenerateLink(link);
    setTimeout(() => {
      onShare();
    }, 1000);
  };

  useEffect(() => {
    if (TappedOnMapDetail == true) {
      setTimeout(() => {
        GetMarketByID();
      }, 1000);
    }
  }, [MapId, MapBaseID]);

  return (
    <View
      style={{
        backgroundColor: "#fff",
        height: 650,
        width: Dimensions.get("window").width,
      }}>
      <Statusbar
        barStyle={"dark-content"}
        backgroundColor={theme.colors.primary}
      />
      <LoadingSpinner
        textContent="Loading..."
        size={60}
        visible={loading}
        color={theme.colors.yellow}
      />

      <DatePicker
        modal
        open={open}
        date={date || new Date()}
        mode={"date"}
        onConfirm={date => {
          setOpen(false);
          setDate(date);
        }}
        onCancel={() => {
          setOpen(false);
        }}
      />
      <DatePicker
        modal
        open={openTime_1}
        date={openTime || new Date()}
        mode={"time"}
        onConfirm={openTime => {
          setOpenTime_1(false);
          setOpenTime(openTime);
        }}
        onCancel={() => {
          setOpenTime_1(false);
        }}
      />
      <DatePicker
        modal
        open={closeTime_2}
        date={closeTime || new Date()}
        mode={"time"}
        onConfirm={closeTime => {
          setCloseTime_2(false);
          setCloseTime(closeTime);
        }}
        onCancel={() => {
          setCloseTime_2(false);
        }}
      />
      {/* {latitude == '' && longitude == '' ? (
        <ActivityIndicator
          size={'small'}
          style={{margin: 2}}
          color={theme.colors.yellow}
        />
      ) : ( */}
      <MapView
        // zoomControlEnabled={true}
        ref={mapRef}
        showsMyLocationButton={false}
        showsUserLocation={true}
        initialRegion={{
          latitude: latitude || 0,
          longitude: longitude || 0,
          latitudeDelta: LATITUDE_DELTA,
          longitudeDelta: LONGITUDE_DELTA,
        }}
        // onMapReady={onZoomInPress}

        style={{flex: 1}}>
        {Add == false ? (
          data?.map((item, index) => (
            <Marker
              onPress={() => {
                setModal_2(true);
                setSetSinglemarketdata(item);
              }}
              draggable={true}
              key={index}
              onDragEnd={v => {
                UpdateMarket_Lat_Long(
                  item?.id,
                  v?.nativeEvent?.coordinate?.latitude,
                  v?.nativeEvent?.coordinate?.longitude,
                );
              }}
              coordinate={{
                latitude: parseFloat(item.lat) || 0,
                longitude: parseFloat(item.long) || 0,
              }}>
              <View
                style={{
                  alignItems: "center",
                  borderRadius: 100,
                  paddingVertical: 20,
                  paddingHorizontal: 10,
                }}>
                <TextFormated
                  numberOfLines={1}
                  style={{
                    fontWeight: "700",
                    color: item?.attendees.find(v => v?.id == auth?.id)
                      ? theme.colors.green
                      : theme.colors.red,
                    fontSize: 12,
                    width: 100,
                    textAlign: "center",
                  }}>
                  {item?.attendees?.length}
                </TextFormated>
                <TextFormated
                  numberOfLines={1}
                  style={{
                    fontWeight: "600",
                    color: item?.attendees.find(v => v?.id == auth?.id)
                      ? theme.colors.green
                      : theme.colors.red,
                    fontSize: 10,
                    width: 100,
                    textAlign: "center",
                  }}>
                  {item?.market_name}
                </TextFormated>
                <TextFormated
                  numberOfLines={1}
                  style={{
                    fontWeight: "600",
                    color: item?.attendees.find(v => v?.id == auth?.id)
                      ? theme.colors.green
                      : theme.colors.red,
                    fontSize: 10,
                    width: 100,
                    textAlign: "center",
                  }}>
                  {moment(item?.date_time).format("ll")}
                </TextFormated>
                <TextFormated
                  numberOfLines={1}
                  style={{
                    fontWeight: "600",
                    width: 100,
                    color: item?.attendees.find(v => v?.id == auth?.id)
                      ? theme.colors.green
                      : theme.colors.red,
                    fontSize: 10,
                    textAlign: "center",
                  }}>
                  {item?.duration}
                </TextFormated>
                <Image
                  source={
                    item?.attendees.find(v => v?.id == auth?.id)
                      ? require("../../../../../assets/Joined.png")
                      : require("../../../../../assets/Deal.png")
                  }
                  style={{width: 24, height: 24}}
                />
              </View>
            </Marker>
          ))
        ) : (
          <Marker
            coordinate={{
              latitude: latitude || 0,
              longitude: longitude || 0,
            }}
            onDragEnd={v => {
              setSelectedLat(v?.nativeEvent?.coordinate?.latitude);
              setSelectedLon(v?.nativeEvent?.coordinate?.longitude);
              setOpenTime(new Date());
              addSomeMinutesToTime();
              setTimeout(() => {
                setModal(true);
              }, 600);
              console.log(v?.nativeEvent?.coordinate?.latitude);
              console.log(v?.nativeEvent?.coordinate?.longitude);
            }}
            draggable
          />
        )}

        {/* PIN AND ANTENA MARKERS */}
        {pinCreate == false ? (
          AllAnteena?.map((item, index) => [
            <Marker
              onPress={() => {
                setSingleAnteenaData(item);
                setPinName(item?.name);
                setTimeout(() => {
                  setModalThree(true);
                }, 100);
              }}
              draggable={true}
              key={index}
              onDragEnd={v => {
                UpdateAnteena_Lat_Long(
                  item?.id,
                  v?.nativeEvent?.coordinate?.latitude,
                  v?.nativeEvent?.coordinate?.longitude,
                );
              }}
              coordinate={{
                latitude: parseFloat(item?.lat) || 0,
                longitude: parseFloat(item?.long) || 0,
              }}>
              <View
                style={{
                  alignItems: "center",
                  paddingHorizontal: 10,
                  paddingVertical: 40,
                }}>
                <View
                  style={{
                    alignItems: "center",
                    paddingHorizontal: 5,
                    paddingVertical: 5,
                    backgroundColor: theme.colors.red,
                    borderRadius: 100,
                  }}>
                  <Image
                    source={require("../../../../../assets/wifi.png")}
                    style={{
                      width: 13,
                      height: 13,
                      tintColor: theme.colors.primary,
                    }}
                  />
                </View>
                {item?.creator_user_id == auth.id && (
                  <TextFormated
                    numberOfLines={2}
                    style={{
                      fontWeight: "700",
                      width: 100,
                      color: theme.colors.red,
                      fontSize: 10,
                      textAlign: "center",
                    }}>
                    {item?.name}
                  </TextFormated>
                )}
              </View>
            </Marker>,
            <Circle
              center={{
                latitude: parseFloat(item?.lat) || 0,
                longitude: parseFloat(item?.long) || 0,
              }}
              radius={0}
              style={{borderColor: "red"}}
              draggable={true}
            />,
          ])
        ) : (
          <Marker
            coordinate={{
              latitude: latitude || 0,
              longitude: longitude || 0,
            }}
            onDragEnd={v => {
              setSelectedLat_pin(v?.nativeEvent?.coordinate?.latitude);
              setSelectedLon_pin(v?.nativeEvent?.coordinate?.longitude);
              setTimeout(() => {
                setModalThree(true);
              }, 600);
            }}
            draggable
          />
        )}
        {/* PIN AND ANTENA MARKERS */}
      </MapView>
      {/* )} */}

      <TouchableOpacity
        onPress={() => {
          currentLocation();
          mapRef.current.animateToRegion({
            latitude: latitude || 0,
            longitude: longitude || 0,
            latitudeDelta: LATITUDE_DELTA,
            longitudeDelta: LONGITUDE_DELTA,
          });
        }}
        style={{
          // paddingVertical: 15,
          // paddingHorizontal: 15,
          backgroundColor: theme.colors.primary,
          borderRadius: 120,
          position: "absolute",
          top: 20,
          right: 20,
          shadowColor: "#000",
          shadowOffset: {
            width: 0,
            height: 2,
          },
          shadowOpacity: 0.25,
          shadowRadius: 3.84,

          elevation: 5,
          paddingVertical: 5,
          paddingHorizontal: 5,
        }}>
        <Image
          style={{
            height: 20,
            width: 20,
            resizeMode: "cover",
            // tintColor: theme.colors.primary,
            borderRadius: 150,
          }}
          source={require("../../../../../assets/Mygps.png")}
        />
      </TouchableOpacity>

      <TouchableOpacity
        onPress={() => {
          setpinCreate(true);
        }}
        style={{
          borderRadius: 120,
          position: "absolute",
          top: Dimensions.get("window").height / 1.9,
          right: 20,
          shadowColor: "#000",
          shadowOffset: {
            width: 0,
            height: 2,
          },
          shadowOpacity: 0.25,
          shadowRadius: 3.84,
          elevation: 5,
          overflow: "hidden",
          backgroundColor: theme.colors.red,
          height: 50,
          width: 50,
          alignItems: "center",
          justifyContent: "center",
        }}>
        <Image
          style={{
            height: 25,
            width: 25,
            resizeMode: "contain",
            tintColor: theme.colors.primary,
          }}
          source={require("../../../../../assets/wifi.png")}
        />
      </TouchableOpacity>

      <TouchableOpacity
        onPress={() => {
          setAdd(true);
        }}
        style={{
          borderRadius: 120,
          position: "absolute",
          top: Dimensions.get("window").height / 1.65,
          right: 20,
          shadowColor: "#000",
          shadowOffset: {
            width: 0,
            height: 2,
          },
          shadowOpacity: 0.25,
          shadowRadius: 3.84,
          elevation: 5,
          overflow: "hidden",
          backgroundColor: theme.colors.green,
          height: 50,
          width: 50,
          alignItems: "center",
          justifyContent: "center",
        }}>
        <Image
          style={{
            height: 50,
            width: 50,
            resizeMode: "contain",
          }}
          source={require("../../../../../assets/Joined.png")}
        />
      </TouchableOpacity>

      <Modal
        animationType="fade"
        visible={modal}
        onDismiss={() => {
          setModal(false);
          setSetSinglemarketdata();
        }}
        transparent
        style={{}}>
        <TouchableOpacity
          onPress={() => {
            setModal(false);
            setAdd(false);
            setSetSinglemarketdata();
          }}
          activeOpacity={1}
          style={{
            justifyContent: "center",
            alignItems: "center",
            backgroundColor: "transparent",
            backgroundColor: theme.colors.Black + "33",
            width: Dimensions.get("window").width,
            height: Dimensions.get("window").height,
          }}>
          <TouchableOpacity
            activeOpacity={1}
            style={{
              backgroundColor: theme.colors.primary,
              width: Dimensions.get("window").width / 1.8,
              height: Dimensions.get("window").width - 120,
              alignItems: "center",
              marginBottom: isKeyboardVisible
                ? Dimensions.get("window").width / 3.5
                : 0,
              borderRadius: 20,
              // borderWidth: 0.4,
              borderColor: theme.colors.Light_Gray,
              // marginBottom: 45,
            }}>
            {/* <KeyboardAvoidingView style={{flex: 1}} behavior="padding"> */}
            <View
              style={{
                flex: 1,
                justifyContent: "center",
                borderRadius: 20,
                overflow: "hidden",
                alignItems: "flex-start",
              }}>
              <ScrollView style={{paddingVertical: 15}}>
                <CustomTextInput
                  View_marginTop={0}
                  paddingTop={8}
                  paddingBottom={8}
                  paddingHorizontal={0.1}
                  marginTop={0}
                  width={Dimensions.get("window").width / 2}
                  placeholder="Market Name"
                  value={market_name}
                  onChangeText={setMarket_name}
                  autoFocus={true}
                  borderWidth={1}
                  borderRadius={6}
                />
                <TouchableOpacity
                  onPress={() => setOpen(true)}
                  style={{flexDirection: "row", alignItems: "center"}}>
                  <View
                    style={{
                      backgroundColor: theme.colors.inputBG,
                      borderRadius: 6,
                      alignItems: "flex-start",
                      width: Dimensions.get("window").width / 2,
                      borderWidth: 1,
                      borderColor: "red",
                      marginTop: 10,
                      shadowColor: "#000",
                      shadowOffset: {
                        width: 0,
                        height: 1,
                      },
                      shadowOpacity: 0.2,
                      shadowRadius: 1.41,

                      elevation: 2,
                      borderColor: theme.colors.C4C4C4,
                    }}>
                    {!date ? (
                      <TextFormated
                        style={{
                          fontWeight: "500",
                          paddingVertical: 10,
                          color: theme.colors.Gray,
                          flex: 1,
                          paddingHorizontal: 15,
                        }}>
                        Date
                      </TextFormated>
                    ) : (
                      <TextFormated
                        style={{
                          fontWeight: "500",
                          paddingVertical: 10,
                          color: theme.colors.Black,
                          flex: 1,
                          paddingHorizontal: 15,
                        }}>
                        {moment(date).format("ll")}
                      </TextFormated>
                    )}
                  </View>
                </TouchableOpacity>

                <TouchableOpacity
                  onPress={() => setOpenTime_1(true)}
                  style={{flexDirection: "row", alignItems: "center"}}>
                  <View
                    style={{
                      backgroundColor: theme.colors.inputBG,
                      borderRadius: 6,
                      alignItems: "flex-start",
                      width: Dimensions.get("window").width / 2,
                      borderWidth: 1,
                      borderColor: "red",
                      marginTop: 10,
                      shadowColor: "#000",
                      shadowOffset: {
                        width: 0,
                        height: 1,
                      },
                      shadowOpacity: 0.2,
                      shadowRadius: 1.41,

                      elevation: 2,
                      borderColor: theme.colors.C4C4C4,
                    }}>
                    {!openTime ? (
                      <TextFormated
                        style={{
                          fontWeight: "500",
                          paddingVertical: 10,
                          color: theme.colors.Gray,
                          flex: 1,
                          paddingHorizontal: 15,
                        }}>
                        Market Open Time
                      </TextFormated>
                    ) : (
                      <TextFormated
                        style={{
                          fontWeight: "500",
                          paddingVertical: 10,
                          color: theme.colors.Black,
                          flex: 1,
                          paddingHorizontal: 15,
                        }}>
                        {moment(openTime).format("LT")}
                      </TextFormated>
                    )}
                  </View>
                </TouchableOpacity>

                <TouchableOpacity
                  onPress={() => setCloseTime_2(true)}
                  style={{flexDirection: "row", alignItems: "center"}}>
                  <View
                    style={{
                      backgroundColor: theme.colors.inputBG,
                      borderRadius: 6,
                      alignItems: "flex-start",
                      width: Dimensions.get("window").width / 2,
                      borderWidth: 1,
                      borderColor: "red",
                      marginTop: 10,
                      shadowColor: "#000",
                      shadowOffset: {
                        width: 0,
                        height: 1,
                      },
                      shadowOpacity: 0.2,
                      shadowRadius: 1.41,

                      elevation: 2,
                      borderColor: theme.colors.C4C4C4,
                    }}>
                    {!closeTime ? (
                      <TextFormated
                        style={{
                          fontWeight: "500",
                          paddingVertical: 10,
                          color: theme.colors.Gray,
                          flex: 1,
                          paddingHorizontal: 15,
                        }}>
                        Market Close Time
                      </TextFormated>
                    ) : (
                      <TextFormated
                        style={{
                          fontWeight: "500",
                          paddingVertical: 10,
                          color: theme.colors.Black,
                          flex: 1,
                          paddingHorizontal: 15,
                        }}>
                        {moment(closeTime).format("LT")}
                      </TextFormated>
                    )}
                  </View>
                </TouchableOpacity>

                <TouchableOpacity
                  onPress={() => {
                    if (!market_name) {
                      ShowToast("Please enter your market name.", "error");
                      return;
                    }
                    if (!date) {
                      ShowToast(
                        "Please select your market opening date.",
                        "error",
                      );
                      return;
                    }
                    if (!openTime) {
                      ShowToast(
                        "Please select your market open time.",
                        "error",
                      );
                      return;
                    }
                    if (!closeTime) {
                      ShowToast(
                        "Please select your market close time.",
                        "error",
                      );
                      return;
                    }
                    navigation.navigate("SelectProduct", {
                      market_name: market_name,
                      date: date,
                      openTime: openTime,
                      closeTime: closeTime,
                      selectedLat: selectedLat,
                      selectedLon: selectedLon,
                      users: UsersAroundUs,
                    });
                    setTimeout(() => {
                      setModal(false);
                      // setSelectedLat();
                      // setSelectedLon();
                      // setDate();
                      // setOpenTime();
                      // setCloseTime();
                      // setMarket_name();
                    }, 100);
                  }}
                  style={{
                    alignItems: "center",
                    justifyContent: "center",
                    paddingVertical: 10,
                    flexDirection: "row",
                    borderRadius: 6,
                    backgroundColor: theme.colors.green,
                    // flex: 1,
                    shadowColor: "#000",
                    shadowOffset: {
                      width: 0,
                      height: 2,
                    },
                    shadowOpacity: 0.25,
                    shadowRadius: 3.84,

                    elevation: 5,
                    marginVertical: 20,
                  }}>
                  <TextFormated
                    style={{
                      fontWeight: "700",
                      color: theme.colors.primary,
                      fontSize: 16,
                    }}>
                    NEXT
                  </TextFormated>
                </TouchableOpacity>
                {/* <TouchableOpacity
                  onPress={() => {
                    AddMarket();
                  }}
                  style={{
                    alignItems: 'center',
                    justifyContent: 'center',
                    paddingVertical: 10,
                    flexDirection: 'row',
                    borderRadius: 6,
                    backgroundColor: theme.colors.green,
                    // flex: 1,
                    shadowColor: '#000',
                    shadowOffset: {
                      width: 0,
                      height: 2,
                    },
                    shadowOpacity: 0.25,
                    shadowRadius: 3.84,

                    elevation: 5,
                    marginVertical: 20,
                  }}>
                  {loading ? (
                    <ActivityIndicator
                      size={'small'}
                      style={{margin: 2}}
                      color="#fff"
                    />
                  ) : (
                    <TextFormated
                      style={{
                        fontWeight: '700',
                        color: theme.colors.primary,
                        fontSize: 16,
                      }}>
                      SUBMIT
                    </TextFormated>
                  )}
                </TouchableOpacity> */}
              </ScrollView>
            </View>
            {/* </KeyboardAvoidingView> */}
          </TouchableOpacity>
        </TouchableOpacity>
      </Modal>

      <Modal
        visible={Modal_2}
        animationType="none"
        onDismiss={() => {
          setModal_2(false);
          setGenerateLink("");
        }}
        transparent
        style={{}}>
        <TouchableOpacity
          onPress={() => {
            setModal_2(false);
            setGenerateLink("");
          }}
          activeOpacity={1}
          style={{
            justifyContent: "center",
            alignItems: "center",
            backgroundColor: "transparent",
            backgroundColor: theme.colors.Black + "33",
            width: Dimensions.get("window").width,
            height: Dimensions.get("window").height,
          }}>
          <TouchableOpacity
            activeOpacity={1}
            style={{
              backgroundColor: theme.colors.primary,
              width: Dimensions.get("window").width / 1.5,
              height: Dimensions.get("window").height / 2.25,
              alignItems: "center",
              borderRadius: 20,
              borderColor: theme.colors.Light_Gray,
              // justifyContent: 'center',
              // borderWidth: 0.4,
              // marginBottom: 45,
              paddingHorizontal: 10,
            }}>
            {joined == false && deleted == false ? (
              <View
                style={{
                  flex: 1,
                  justifyContent: "center",
                  borderRadius: 20,
                  overflow: "hidden",
                  alignItems: "flex-start",
                }}>
                <ScrollView style={{paddingVertical: 15}}>
                  <View
                    style={{
                      backgroundColor: theme.colors.primary,
                      borderRadius: 6,
                      alignItems: "center",
                      borderColor: "red",
                    }}>
                    <TextFormated
                      style={{
                        fontWeight: "700",
                        color: theme.colors.Black,
                        fontSize: 18,
                      }}>
                      {setSinglemarketdata?.attendees?.length}
                    </TextFormated>
                    <TextFormated
                      style={{
                        color: theme.colors.Black,
                        fontSize: 10,
                      }}>
                      Attendees
                    </TextFormated>
                  </View>

                  <CustomTextInput
                    View_marginTop={0}
                    paddingTop={8}
                    paddingBottom={8}
                    paddingHorizontal={0.1}
                    marginTop={0}
                    width={Dimensions.get("window").width / 1.7}
                    placeholder="Market Name"
                    value={setSinglemarketdata?.market_name}
                    // onChangeText={setPrice}
                    autoFocus={true}
                    borderWidth={1}
                    borderRadius={6}
                    editable={false}
                  />

                  <View
                    style={{
                      backgroundColor: theme.colors.inputBG,
                      borderRadius: 6,
                      alignItems: "flex-start",
                      width: Dimensions.get("window").width / 1.7,
                      borderWidth: 1,
                      borderColor: "red",
                      marginTop: 10,
                      shadowColor: "#000",
                      shadowOffset: {
                        width: 0,
                        height: 1,
                      },
                      shadowOpacity: 0.2,
                      shadowRadius: 1.41,

                      elevation: 2,
                      borderColor: theme.colors.C4C4C4,
                    }}>
                    <TextFormated
                      style={{
                        fontWeight: "500",
                        paddingVertical: 10,
                        color: theme.colors.Black,
                        flex: 1,
                        paddingHorizontal: 15,
                      }}>
                      {moment(setSinglemarketdata?.date_time).format("ll")}
                    </TextFormated>
                  </View>
                  <CustomTextInput
                    View_marginTop={0}
                    paddingTop={8}
                    paddingBottom={8}
                    paddingHorizontal={0.1}
                    marginTop={0}
                    width={Dimensions.get("window").width / 1.7}
                    placeholder="Duration"
                    value={setSinglemarketdata?.duration}
                    autoFocus={true}
                    borderWidth={1}
                    borderRadius={6}
                    editable={false}
                  />
                  {setSinglemarketdata?.attendees.find(
                    v => v?.id == auth?.id,
                  ) ? (
                    <View>
                      <TouchableOpacity
                        onPress={() => {
                          LeaveMarket(setSinglemarketdata?.id);
                        }}
                        style={{
                          alignItems: "center",
                          justifyContent: "center",
                          paddingVertical: 10,
                          flexDirection: "row",
                          borderRadius: 6,
                          backgroundColor: theme.colors.red,
                          // flex: 1,
                          shadowColor: "#000",
                          shadowOffset: {
                            width: 0,
                            height: 2,
                          },
                          shadowOpacity: 0.25,
                          shadowRadius: 3.84,

                          elevation: 5,
                          marginTop: 20,
                        }}>
                        {loading ? (
                          <ActivityIndicator
                            size={"small"}
                            style={{margin: 2}}
                            color="#fff"
                          />
                        ) : (
                          <TextFormated
                            style={{
                              fontWeight: "700",
                              color: theme.colors.primary,
                            }}>
                            LEAVE
                          </TextFormated>
                        )}
                      </TouchableOpacity>
                      {setSinglemarketdata?.creator_user_id == auth?.id && (
                        <TouchableOpacity
                          onPress={() => {
                            if (
                              setSinglemarketdata?.creator_user_id == auth?.id
                            ) {
                              // setLoading_2(true);
                              setTimeout(() => {
                                DeleteMarket(setSinglemarketdata?.id);
                              }, 500);
                            }
                          }}
                          style={{
                            alignItems: "center",
                            justifyContent: "center",
                            paddingVertical: 10,
                            flexDirection: "row",
                            borderRadius: 6,
                            backgroundColor:
                              setSinglemarketdata?.creator_user_id ==
                                auth?.id && theme.colors.red,
                            // flex: 1,
                            shadowColor: "#000",
                            shadowOffset: {
                              width: 0,
                              height: 2,
                            },
                            shadowOpacity: 0.25,
                            shadowRadius: 3.84,

                            elevation: 5,
                            marginTop: 20,
                          }}>
                          {loading_2 ? (
                            <ActivityIndicator
                              size={"small"}
                              style={{margin: 2}}
                              color="#fff"
                            />
                          ) : (
                            <TextFormated
                              style={{
                                fontWeight: "700",
                                color: theme.colors.primary,
                              }}>
                              {setSinglemarketdata?.creator_user_id ==
                                auth?.id && "DELETE"}
                            </TextFormated>
                          )}
                        </TouchableOpacity>
                      )}
                    </View>
                  ) : (
                    <View>
                      <TouchableOpacity
                        onPress={() => {
                          setLoading(true);
                          setTimeout(() => {
                            JoinMarket(setSinglemarketdata?.id);
                          }, 500);
                        }}
                        style={{
                          alignItems: "center",
                          justifyContent: "center",
                          paddingVertical: 10,
                          flexDirection: "row",
                          borderRadius: 6,
                          backgroundColor: theme.colors.green,
                          // flex: 1,
                          shadowColor: "#000",
                          shadowOffset: {
                            width: 0,
                            height: 2,
                          },
                          shadowOpacity: 0.25,
                          shadowRadius: 3.84,

                          elevation: 5,
                          marginTop: 20,
                        }}>
                        {loading ? (
                          <ActivityIndicator
                            size={"small"}
                            style={{margin: 2}}
                            color="#fff"
                          />
                        ) : (
                          <TextFormated
                            style={{
                              fontWeight: "700",
                              color: theme.colors.primary,
                            }}>
                            JOIN
                          </TextFormated>
                        )}
                      </TouchableOpacity>
                      {setSinglemarketdata?.creator_user_id == auth?.id && (
                        <TouchableOpacity
                          onPress={() => {
                            if (
                              setSinglemarketdata?.creator_user_id == auth?.id
                            ) {
                              setLoading_2(false);
                              setTimeout(() => {
                                DeleteMarket(setSinglemarketdata?.id);
                              }, 500);
                            }
                          }}
                          style={{
                            alignItems: "center",
                            justifyContent: "center",
                            paddingVertical: 10,
                            flexDirection: "row",
                            borderRadius: 6,
                            backgroundColor:
                              setSinglemarketdata?.creator_user_id ==
                                auth?.id && theme.colors.red,
                            // flex: 1,
                            shadowColor: "#000",
                            shadowOffset: {
                              width: 0,
                              height: 2,
                            },
                            shadowOpacity: 0.25,
                            shadowRadius: 3.84,

                            elevation: 5,
                            marginTop: 20,
                          }}>
                          {loading_2 ? (
                            <ActivityIndicator
                              size={"small"}
                              style={{margin: 2}}
                              color="#fff"
                            />
                          ) : (
                            <TextFormated
                              style={{
                                fontWeight: "700",
                                color: theme.colors.primary,
                              }}>
                              {setSinglemarketdata?.creator_user_id ==
                                auth?.id && "DELETE"}
                            </TextFormated>
                          )}
                        </TouchableOpacity>
                      )}
                    </View>
                  )}
                  <TouchableOpacity
                    onPress={() => {
                      buildLink();
                    }}
                    style={{
                      alignItems: "center",
                      justifyContent: "center",
                      paddingVertical: 10,
                      flexDirection: "row",
                      borderRadius: 6,
                      backgroundColor: theme.colors.green,
                      // flex: 1,
                      shadowColor: "#000",
                      shadowOffset: {
                        width: 0,
                        height: 2,
                      },
                      shadowOpacity: 0.25,
                      shadowRadius: 3.84,

                      elevation: 5,
                      marginTop: 20,
                    }}>
                    <TextFormated
                      style={{
                        fontWeight: "700",
                        color: theme.colors.primary,
                      }}>
                      SHARE
                    </TextFormated>
                  </TouchableOpacity>
                </ScrollView>
              </View>
            ) : (
              <TouchableOpacity
                activeOpacity={1}
                style={{
                  backgroundColor: theme.colors.primary,
                  width: Dimensions.get("window").width / 1.8,
                  height: Dimensions.get("window").width - 140,
                  alignItems: "center",
                  borderRadius: 20,
                  borderColor: theme.colors.Light_Gray,
                  justifyContent: "center",
                }}>
                <TouchableOpacity
                  onPress={() => {
                    setAdd(true);
                  }}
                  style={{
                    justifyContent: "center",
                    alignItems: "center",
                  }}>
                  <Image
                    style={{
                      width: Dimensions.get("window").width / 2.8,
                      height: Dimensions.get("window").width / 2.8,
                      resizeMode: "cover",
                      // tintColor: theme.colors.primary,
                      borderRadius: 150,
                      alignSelf: "center",
                    }}
                    // source={require('../../../../../assets/gif/delete.gif')}
                    source={
                      deleted == true
                        ? require("../../../../../assets/gif/delete.gif")
                        : require("../../../../../assets/gif/Success.gif")
                    }
                  />
                  {Leave == false ? (
                    <TextFormated
                      style={{
                        fontWeight: "700",
                        color:
                          deleted == true
                            ? theme.colors.red
                            : theme.colors.green,
                        alignSelf: "center",
                        fontSize: 20,
                        textAlign: "center",
                      }}>
                      {deleted == true
                        ? "Market Deleted Successfully"
                        : "Market Joined Successfully"}
                    </TextFormated>
                  ) : (
                    <TextFormated
                      style={{
                        fontWeight: "700",
                        color:
                          deleted == true
                            ? theme.colors.red
                            : theme.colors.green,
                        alignSelf: "center",
                        fontSize: 20,
                        textAlign: "center",
                      }}>
                      Market Leaved Successfully
                    </TextFormated>
                  )}
                </TouchableOpacity>
              </TouchableOpacity>
            )}
          </TouchableOpacity>
        </TouchableOpacity>
      </Modal>

      <Modal
        visible={modalThree}
        animationType="none"
        onDismiss={() => {
          setModalThree(false);
          setpinCreate(false);
          setPinName("");
          setSingleAnteenaData();
        }}
        transparent
        style={{}}>
        <TouchableOpacity
          onPress={() => {
            setModalThree(false);
            setSingleAnteenaData();
            setpinCreate(false);
            setPinName("");
          }}
          activeOpacity={1}
          style={{
            justifyContent: "center",
            alignItems: "center",
            backgroundColor: "transparent",
            backgroundColor: theme.colors.Black + "33",
            width: Dimensions.get("window").width,
            height: Dimensions.get("window").height,
          }}>
          <TouchableOpacity
            activeOpacity={1}
            style={{
              backgroundColor: theme.colors.primary,
              width: Dimensions.get("window").width / 1.5,
              height: Dimensions.get("window").height / 4.5,
              alignItems: "center",
              borderRadius: 20,
              borderColor: theme.colors.Light_Gray,
              paddingHorizontal: 10,
            }}>
            {PinCreationAnimat == false ? (
              <View
                style={{
                  flex: 1,
                  justifyContent: "center",
                  borderRadius: 20,
                  overflow: "hidden",
                  alignItems: "flex-start",
                }}>
                <ScrollView style={{paddingVertical: 15}}>
                  <CustomTextInput
                    View_marginTop={0}
                    paddingTop={8}
                    paddingBottom={8}
                    paddingHorizontal={0.1}
                    marginTop={0}
                    width={Dimensions.get("window").width / 1.7}
                    placeholder="Pin Name"
                    value={PinName}
                    onChangeText={setPinName}
                    autoFocus={true}
                    borderWidth={1}
                    borderRadius={6}
                  />

                  {SingleAnteenaData != undefined && (
                    <TouchableOpacity
                      onPress={() => {
                        SingleAnteenaData?.name == PinName
                          ? setModalThree(false)
                          : UpdateAnteena_Name();
                      }}
                      style={{
                        alignItems: "center",
                        justifyContent: "center",
                        paddingVertical: 10,
                        flexDirection: "row",
                        borderRadius: 6,
                        backgroundColor: theme.colors.green,
                        // flex: 1,
                        shadowColor: "#000",
                        shadowOffset: {
                          width: 0,
                          height: 2,
                        },
                        shadowOpacity: 0.25,
                        shadowRadius: 3.84,

                        elevation: 5,
                        marginTop: 20,
                      }}>
                      {loading ? (
                        <ActivityIndicator
                          size={"small"}
                          style={{margin: 2}}
                          color={theme.colors.primary}
                        />
                      ) : (
                        <TextFormated
                          style={{
                            fontWeight: "700",
                            color: theme.colors.primary,
                          }}>
                          {SingleAnteenaData?.name == PinName
                            ? "DONE"
                            : "UPDATE PIN"}
                        </TextFormated>
                      )}
                    </TouchableOpacity>
                  )}

                  {SingleAnteenaData == undefined && (
                    <TouchableOpacity
                      onPress={() => {
                        CreatePin();
                      }}
                      style={{
                        alignItems: "center",
                        justifyContent: "center",
                        paddingVertical: 10,
                        flexDirection: "row",
                        borderRadius: 6,
                        backgroundColor: theme.colors.green,
                        // flex: 1,
                        shadowColor: "#000",
                        shadowOffset: {
                          width: 0,
                          height: 2,
                        },
                        shadowOpacity: 0.25,
                        shadowRadius: 3.84,

                        elevation: 5,
                        marginTop: 20,
                      }}>
                      {loading ? (
                        <ActivityIndicator
                          size={"small"}
                          style={{margin: 2}}
                          color={theme.colors.primary}
                        />
                      ) : (
                        <TextFormated
                          style={{
                            fontWeight: "700",
                            color: theme.colors.primary,
                          }}>
                          CREATE PIN
                        </TextFormated>
                      )}
                    </TouchableOpacity>
                  )}
                  {SingleAnteenaData?.creator_user_id == auth?.id && (
                    <TouchableOpacity
                      onPress={() => {
                        DeletePin();
                      }}
                      style={{
                        alignItems: "center",
                        justifyContent: "center",
                        paddingVertical: 10,
                        flexDirection: "row",
                        borderRadius: 6,
                        backgroundColor: theme.colors.red,
                        // flex: 1,
                        shadowColor: "#000",
                        shadowOffset: {
                          width: 0,
                          height: 2,
                        },
                        shadowOpacity: 0.25,
                        shadowRadius: 3.84,

                        elevation: 5,
                        marginTop: 20,
                      }}>
                      {PinDeleteLoading ? (
                        <ActivityIndicator
                          size={"small"}
                          style={{margin: 2}}
                          color={theme.colors.primary}
                        />
                      ) : (
                        <TextFormated
                          style={{
                            fontWeight: "700",
                            color: theme.colors.primary,
                          }}>
                          DELETE PIN
                        </TextFormated>
                      )}
                    </TouchableOpacity>
                  )}
                </ScrollView>
              </View>
            ) : (
              <TouchableOpacity
                activeOpacity={1}
                style={{
                  backgroundColor: theme.colors.primary,
                  width: Dimensions.get("window").width / 1.5,
                  height: Dimensions.get("window").height / 4.5,
                  alignItems: "center",
                  borderRadius: 20,
                  borderColor: theme.colors.Light_Gray,
                  justifyContent: "center",
                }}>
                <TouchableOpacity
                  onPress={() => {}}
                  style={{justifyContent: "center", alignItems: "center"}}>
                  <Image
                    style={{
                      width: Dimensions.get("window").width / 3.3,
                      height: Dimensions.get("window").width / 3.3,
                      resizeMode: "cover",
                      // tintColor: theme.colors.primary,
                      borderRadius: 150,
                      alignSelf: "center",
                    }}
                    source={
                      pinCreate == true
                        ? require("../../../../../assets/gif/delete.gif")
                        : require("../../../../../assets/gif/Success.gif")
                    }
                  />
                  <TextFormated
                    style={{
                      fontWeight: "700",
                      color:
                        pinCreate == true
                          ? theme.colors.red
                          : theme.colors.green,
                      alignSelf: "center",
                      fontSize: 18,
                      textAlign: "center",
                    }}>
                    {pinCreate == true
                      ? "Pin Deleted Successfully"
                      : "Pin Created Successfully"}
                  </TextFormated>
                </TouchableOpacity>
              </TouchableOpacity>
            )}
          </TouchableOpacity>
        </TouchableOpacity>
      </Modal>
    </View>
  );
}
