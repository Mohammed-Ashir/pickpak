import { Text, View } from 'react-native'
import React, { Component } from 'react'
import Home from './Screen/Home';

export class App extends Component {
  render() {
    return (
      <View>
      <Home />
      </View>
    )
  }
}

export default App;